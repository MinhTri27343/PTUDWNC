import {buildSchema,graphql,GraphQLError} from 'graphql';
import DataLoader from 'dataloader';
import type {Express,Response} from 'express';
import {partError,UpstreamError} from '../public/shared.js';
type Call=(scope:'user'|'orders'|'product',route:string,options?:any)=>Promise<any>;
const schema=buildSchema(`
 enum ProductMode { NAIVE BATCHED }
 type Query { user(id:ID!):User orders(user_id:ID!,product_mode:ProductMode=BATCHED):[Order!] }
 type User { id:ID! name:String! }
 type Order { id:ID! user_id:ID! product_id:ID! quantity:Int! total_cents:Int! status:String! created_at:String! product:Product }
 type Product { id:ID! name:String! price_cents:Int! thumbnail_url:String! }
`);
function failure(scope:string,error:any,resource_id?:string) {
 const detail=partError(scope,error,resource_id);
 return new GraphQLError(detail.message,{extensions:{...detail}});
}
function valid(value:unknown){return typeof value==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(value);}
export function mountGraphQL(app:Express,createCall:(res:Response)=>Call) {
 app.post('/graphql',async(req,res)=>{
  if(typeof req.body?.query!=='string'||req.body.query.length>20000||req.body.variables!==undefined&&(!req.body.variables||typeof req.body.variables!=='object'||Array.isArray(req.body.variables))) {
   res.status(400).json({errors:[{message:'GraphQL request không hợp lệ.',extensions:{code:'VALIDATION_ERROR'}}]});return;
  }
  const call=createCall(res);
  // A loader is created for every operation, never shared between requests.
  const loader=new DataLoader<string,any>(async keys=>{
   try{
    const result=await call('product','/products/batch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:keys})});
    const products=new Map(result.products.map((product:any)=>[product.id,product]));
    return keys.map(key=>products.get(key)||failure('product',new UpstreamError('RESOURCE_NOT_FOUND'),key));
   }catch(error){return keys.map(key=>failure('product',error,key));}
  });
  const rootValue={
   user:async({id}:{id:string})=>{
    if(!valid(id))throw new GraphQLError('User ID không hợp lệ.',{extensions:{code:'VALIDATION_ERROR',scope:'user'}});
    try{return await call('user',`/users/${encodeURIComponent(id)}`);}catch(error){throw failure('user',error);}
   },
   orders:async({user_id,product_mode}:{user_id:string;product_mode:string})=>{
    if(!valid(user_id))throw new GraphQLError('User ID không hợp lệ.',{extensions:{code:'VALIDATION_ERROR',scope:'orders'}});
    let orders:any[];
    try{orders=(await call('orders',`/orders?user_id=${encodeURIComponent(user_id)}`)).orders;}catch(error){throw failure('orders',error);}
    return orders.map(order=>({...order,product:async()=>{
     if(product_mode==='BATCHED')return loader.load(order.product_id);
     try{return await call('product',`/products/${encodeURIComponent(order.product_id)}`);}catch(error){throw failure('product',error,order.product_id);}
    }}));
   }
  };
  const result=await graphql({schema,source:req.body.query,variableValues:req.body.variables,operationName:req.body.operationName,rootValue});
  res.status(result.data===undefined?400:200).json(result);
 });
}
