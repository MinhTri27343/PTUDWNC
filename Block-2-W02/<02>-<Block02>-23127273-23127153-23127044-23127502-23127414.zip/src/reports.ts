import express from 'express';
import { reportRequests } from './report-timing.ts';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

type Report = { name:string; kind:'healthy'|'failure'; created:string; samples:number };
export function reportsRouter(directory:string) {
  const router = express.Router();
  function list():Report[] {
    if (!fs.existsSync(directory)) return [];
    const reports:Report[] = [];
    for (const entry of fs.readdirSync(directory, { withFileTypes:true })) {
      if (!entry.isDirectory() || !/^(healthy|failure)-[\w-]+$/.test(entry.name)) continue;
      const folder = path.join(directory, entry.name);
      if (!fs.existsSync(path.join(folder,'report.html')) || fs.existsSync(path.join(folder,'SUPERSEDED.txt'))) continue;
      try {
        const raw = JSON.parse(fs.readFileSync(path.join(folder,'raw.json'),'utf8'));
        if (raw.environment?.incomplete || !Array.isArray(raw.rows) || raw.environment?.quick) continue;
        reports.push({ name:entry.name, kind:entry.name.startsWith('healthy-')?'healthy':'failure',
          created:raw.environment.created_at, samples:raw.rows.length });
      } catch { /* Ignore unfinished or malformed artifacts while a collector is writing. */ }
    }
    return reports.sort((a,b)=>b.name.localeCompare(a.name));
  }
  for (const [urls,file] of [
    [['/report','/REPORT.html'],'REPORT.html'],
    [['/report.md','/REPORT.md'],'REPORT.md'],
    [['/README.md'],'README.md'],
    [['/RESULTS.md'],'RESULTS.md']
  ] as [string[],string][]) {
    router.get(urls,(_req,res)=>res.sendFile(fileURLToPath(new URL(`../${file}`,import.meta.url))));
  }
  router.get('/measurements/latest/:kind', (req,res) => {
    if (!['healthy','failure'].includes(req.params.kind)) { res.status(404).send('Báo cáo không tồn tại.'); return; }
    const report = list().find(report=>report.kind===req.params.kind);
    res.redirect(report ? `/measurements?kind=${report.kind}` : '/measurements');
  });
  router.get('/measurements/data', (_req,res) => {
    const reports=list();
    const sources:Record<string,any>={};
    for (const kind of ['healthy','failure']) {
      const entry=reports.find(report=>report.kind===kind);
      if (!entry) continue;
      const folder=path.join(directory,entry.name);
      const raw=JSON.parse(fs.readFileSync(path.join(folder,'raw.json'),'utf8'));
      let equalityCount:null|number=null;
      try { equalityCount=JSON.parse(fs.readFileSync(path.join(folder,'equality.json'),'utf8')).filter((entry:any)=>entry.equal===true).length; } catch {}
      const rows=raw.rows.map((row:any)=>{
        const {events,...sample}=row;
        let outcome=null;
        if (typeof row.run_id==='string' && /^[\w-]+$/.test(row.run_id)) {
          try {
            const model=JSON.parse(fs.readFileSync(path.join(folder,`${row.run_id}.model.json`),'utf8'));
            outcome={orders:model.orders?.length ?? null,
              missingProducts:model.orders?.filter((order:any)=>('product' in order ? order.product===null : order.product_name===null)).length ?? null,
              errors:model.errors};
          } catch {}
        }
        return {...sample,requests:reportRequests(row,folder),outcome};
      });
      sources[kind]={...entry,environment:raw.environment,equalityCount,rows};
    }
    res.set('Cache-Control','no-store').json({sources,reports});
  });
  router.get('/measurements', (_req,res) => {
    res.sendFile(fileURLToPath(new URL('../public/measurements.html',import.meta.url)));
  });
  router.use('/evidence', express.static(directory, { index:false, dotfiles:'deny' }));
  return router;
}
