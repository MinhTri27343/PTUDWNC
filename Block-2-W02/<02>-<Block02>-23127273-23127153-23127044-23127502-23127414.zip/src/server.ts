import express, { type Request, type Response, type NextFunction } from 'express';
import Database from 'better-sqlite3';
import pino from 'pino';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { mountGraphQL } from './graphql.ts';
import { mountDemoControl } from './demo-control.ts';
import { reportsRouter } from './reports.ts';
import { root } from '../scripts/seed.ts';
import { readJson, partError, project, UpstreamError } from '../public/shared.js';
const service = process.argv[2];
const ports: Record<string,number> = { bff:3000, user:3001, order:3002, product:3003 };
if (!(service in ports)) throw new Error('Expected bff|user|order|product');
const port = ports[service];
const logger = pino({ base: { service }, timestamp: pino.stdTimeFunctions.epochTime });
const app = express();
app.disable('x-powered-by');
const db = service === 'bff' ? null : new Database(path.join(root, 'data', `${service}.db`), { fileMustExist:true });
db?.pragma('journal_mode = WAL');
app.use((req, res, next) => {
  const start = Date.now();
  const requestId = randomUUID();
  res.locals.requestId = requestId;
  const rawRun = req.query.run_id ?? req.header('X-Run-Id');
  res.locals.runId = typeof rawRun === 'string' && /^[\w-]{1,100}$/.test(rawRun) ? rawRun : null;
  res.set({ 'X-Request-Id':requestId, 'Cache-Control':'no-store',
    'Access-Control-Allow-Origin':'http://localhost:3000', 'Timing-Allow-Origin':'http://localhost:3000' });
  if (req.path !== '/health' && (service !== 'bff' || (req.path.startsWith('/bff/') || req.path === '/graphql'))) logger.info({ event:'request_start', run_id:res.locals.runId, request_id:requestId, method:req.method, path:req.path, start });
  res.on('finish', () => {
    if (req.path === '/health' || service === 'bff' && !(req.path.startsWith('/bff/') || req.path === '/graphql')) return;
    logger.info({ event:'request', run_id:res.locals.runId, request_id:requestId,
      method:req.method, path:req.path, start, end:Date.now(), status:res.statusCode,
      bytes:Number(res.getHeader('Content-Length') || 0) });
  });
  next();
});
app.use(express.json({ limit:'32kb' }));
app.get('/health', (_req, res) => res.json({ service, ready:true }));
function query(res:Response, sql:string, parameters:unknown[], single = false): any {
  const start = Date.now();
  try {
    const statement = db!.prepare(sql);
    return single ? statement.get(...parameters) : statement.all(...parameters);
  } finally {
    logger.info({ event:'db_query', run_id:res.locals.runId, request_id:res.locals.requestId, sql, start, end:Date.now() });
  }
}
function id(value:unknown): value is string { return typeof value === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(value); }
function bad(res:Response) { return res.status(400).json({ code:'VALIDATION_ERROR', message:'Tham số không hợp lệ.', request_id:res.locals.requestId }); }
function missing(res:Response) { return res.status(404).json({ code:'RESOURCE_NOT_FOUND', message:'Dữ liệu không tồn tại.', request_id:res.locals.requestId }); }
if (service === 'user') app.get('/users/:id', (req, res) => {
  if (!id(req.params.id)) return bad(res);
  const row = query(res, 'SELECT id,name FROM users WHERE id=?', [req.params.id], true);
  return row ? res.json(row) : missing(res);
});
if (service === 'order') app.get('/orders', (req, res) => {
  if (!id(req.query.user_id)) return bad(res);
  return res.json({ orders:query(res, 'SELECT * FROM orders WHERE user_id=? ORDER BY id', [req.query.user_id]) });
});
if (service === 'product') {
  app.use('/products', async (_req, res, next) => {
    const delay = Number(process.env.PRODUCT_DELAY_MS || 0);
    if (delay > 0) await new Promise(resolve => setTimeout(resolve, delay));
    if (process.env.PRODUCT_FAIL === 'true') { res.status(500).json({ code:'SIMULATED_FAILURE', message:'Product service demo failure' }); return; }
    next();
  });
  app.get('/products/:id', (req, res) => {
    if (!id(req.params.id)) return bad(res);
    const row = query(res, 'SELECT * FROM products WHERE id=? AND id<>?', [req.params.id, process.env.PRODUCT_MISSING_ID || ''], true);
    return row ? res.json(row) : missing(res);
  });
  app.post('/products/batch', (req, res) => {
    const ids = req.body?.ids;
    if (!Array.isArray(ids) || !ids.length || ids.length > 100 || !ids.every(id) || Object.keys(req.body).some(key => key !== 'ids')) return bad(res);
    const unique = [...new Set(ids)];
    return res.json({ products:query(res, `SELECT * FROM products WHERE id IN (${unique.map(() => '?').join(',')}) AND id<>? ORDER BY id`, [...unique, process.env.PRODUCT_MISSING_ID || '']) });
  });
}
if (service === 'bff') {
  const urls = { user:'http://localhost:3001', orders:'http://localhost:3002', product:'http://localhost:3003' };
  const createCall = (res:Response) => {
    const call = (scope:keyof typeof urls, route:string, options:any = {}) => {
      const callId = randomUUID();
      return readJson(`${urls[scope]}${route}`, { ...options,
        headers:{ ...options.headers, 'X-Run-Id':res.locals.runId || '', 'X-Parent-Request-Id':res.locals.requestId } },
      (record:any) => logger.info({ event:'service_call', run_id:res.locals.runId, request_id:res.locals.requestId,
        call_id:callId, target:scope === 'orders' ? 'order' : scope, route, ...record }));
    };
    return call;
  };
  mountDemoControl(app);
  mountGraphQL(app, createCall);
  app.get(['/bff/web/dashboard', '/bff/mobile/orders'], async (req, res) => {
    if (!id(req.query.user_id)) return bad(res);
    const uid = req.query.user_id;
    const errors:any[] = [];
    const products = new Map<string,any>();
    const call = createCall(res);
    const [userResult, orderResult] = await Promise.allSettled([
      call('user', `/users/${uid}`), call('orders', `/orders?user_id=${uid}`)
    ]);
    const user = userResult.status === 'fulfilled' ? userResult.value : null;
    const orders = orderResult.status === 'fulfilled' ? orderResult.value.orders : null;
    if (userResult.status === 'rejected') errors.push(partError('user', userResult.reason));
    if (orderResult.status === 'rejected') errors.push(partError('orders', orderResult.reason));
    const ids = [...new Set<string>((orders || []).map((order:any) => order.product_id))];
    if (ids.length) {
      try {
        const response = await call('product', '/products/batch', { method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify({ ids }) });
        for (const product of response.products) products.set(product.id, product);
        for (const productId of ids) if (!products.has(productId)) errors.push(partError('product', new UpstreamError('RESOURCE_NOT_FOUND'), productId));
      } catch (error) { for (const productId of ids) errors.push(partError('product', error, productId)); }
    }
    res.json(project(user, orders, products, errors, req.path.includes('/mobile/') ? 'mobile' : 'web'));
  });
  app.use(reportsRouter(path.join(root, 'evidence')));
  app.use(express.static(path.join(root, 'public')));
}
app.use((_req, res) => res.status(404).json({ code:'NOT_FOUND', message:'Route không tồn tại.', request_id:res.locals.requestId }));
app.use((error:any, _req:Request, res:Response, _next:NextFunction) => {
  const invalid = error.type === 'entity.parse.failed' || error.type === 'entity.too.large';
  logger.error({ event:'error', request_id:res.locals.requestId, run_id:res.locals.runId, err:error });
  res.status(invalid ? 400 : 500).json({ code:invalid ? 'VALIDATION_ERROR' : 'INTERNAL_ERROR', message:invalid ? 'JSON không hợp lệ.' : 'Lỗi server.', request_id:res.locals.requestId });
});
const server = app.listen(port, 'localhost', () => logger.info({ event:'ready', port }));
server.on('error', error => { logger.error(error); process.exit(1); });
for (const signal of ['SIGTERM','SIGINT'] as const) process.on(signal, () => {
  server.close(() => { db?.close(); process.exit(0); });
  setTimeout(() => process.exit(0), 2000).unref();
});
