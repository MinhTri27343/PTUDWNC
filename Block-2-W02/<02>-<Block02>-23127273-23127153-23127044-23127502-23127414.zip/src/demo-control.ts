import type {Express} from 'express';
import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {root} from '../scripts/seed.ts';
export const scenarios:Record<string,Record<string,string>>={healthy:{},slow:{PRODUCT_DELAY_MS:'300'},timeout:{PRODUCT_DELAY_MS:'1500'},error:{PRODUCT_FAIL:'true'},missing:{PRODUCT_MISSING_ID:'P1'}};
export function initialSettings(){
 let dataset='small';try{dataset=JSON.parse(fs.readFileSync(path.join(root,'data/dataset.json'),'utf8')).dataset;}catch{}
 const scenario=process.env.PRODUCT_FAIL==='true'?'error':process.env.PRODUCT_MISSING_ID?'missing':Number(process.env.PRODUCT_DELAY_MS)>=1000?'timeout':Number(process.env.PRODUCT_DELAY_MS)>0?'slow':'healthy';
 return {dataset,scenario};
}
export function mountDemoControl(app:Express){
 let settings=initialSettings(),changing=false,controlsReady=false;
 const pending=new Map<string,{resolve:(value:any)=>void;reject:(error:Error)=>void;timer:NodeJS.Timeout}>();
 process.on('message',(message:any)=>{
  if(message?.type==='demo-ready'){controlsReady=true;return;}
  if(message?.type!=='demo-result')return;
  const operation=pending.get(message.id);if(!operation)return;
  clearTimeout(operation.timer);pending.delete(message.id);
  message.ok?operation.resolve(message.result):operation.reject(new Error(message.error||'Không đổi được cấu hình.'));
 });
 const ipc=(type:string,payload:any)=>new Promise<any>((resolve,reject)=>{
  if(!controlsReady||!process.connected||!process.send){reject(new Error('Chạy demo bằng npm run dev để dùng điều khiển UI.'));return;}
  const id=randomUUID();const timer=setTimeout(()=>{pending.delete(id);reject(new Error('Runner chưa phản hồi.'));},20000);
  pending.set(id,{resolve,reject,timer});process.send({type,id,payload});
 });
 app.use((req,res,next)=>{
  if(changing&&(req.path.startsWith('/bff/')||req.path==='/graphql')){res.status(409).json({code:'DEMO_RECONFIGURING',message:'Đang đổi dữ liệu demo.'});return;}next();
 });
 app.get('/demo/settings',(_req,res)=>res.json({...settings,changing,controls_ready:controlsReady}));
 app.post('/demo/settings',async(req,res)=>{
  const {dataset,scenario}=req.body||{};
  if(!['small','large'].includes(dataset)||!Object.hasOwn(scenarios,scenario)){res.status(400).json({message:'Cấu hình không hợp lệ.'});return;}
  if(changing){res.status(409).json({message:'Một thay đổi cấu hình đang chạy.'});return;}
  if(!controlsReady){res.status(409).json({message:'Bộ đo tự động đang quản lý service; dùng npm run dev để đổi cấu hình UI.'});return;}
  changing=true;
  try{settings=await ipc('demo-settings',{dataset,scenario});res.json(settings);}catch(error:any){res.status(503).json({message:error.message});}finally{changing=false;}
 });
 app.get('/demo/metrics',async(req,res)=>{
  if(typeof req.query.run_id!=='string'||! /^[\w-]{1,100}$/.test(req.query.run_id)){res.status(400).json({message:'run_id không hợp lệ.'});return;}
  try{res.json(await ipc('demo-metrics',{run_id:req.query.run_id}));}catch(error:any){res.status(503).json({message:error.message});}
 });
}
