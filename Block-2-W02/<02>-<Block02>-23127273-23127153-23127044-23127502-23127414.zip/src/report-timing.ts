import fs from 'node:fs';
import path from 'node:path';
/** Older Playwright aborted requests may have startTime=0. Recover only missing timing from the saved HAR; keep original artifacts unchanged. */
export function reportRequests(row:any, directory:string) {
  const requests=row.requests || [];
  if (!requests.some((request:any)=>!(request.absoluteStart>0) || !Number.isFinite(request.start) || request.start < -10000)) return requests;
  const reference=requests.find((request:any)=>request.absoluteStart>0 && Number.isFinite(request.start) && request.start>=-10000);
  const origin=reference ? reference.absoluteStart-reference.start : null;
  const entries=new Map<string,any[]>();
  if (origin!==null && typeof row.run_id==='string' && /^[\w-]+$/.test(row.run_id)) {
    try {
      const har=JSON.parse(fs.readFileSync(path.join(directory,`${row.run_id}.har`),'utf8'));
      for (const entry of har.log.entries) {
        const key=`${entry.request.method} ${entry.request.url}`;
        if (!entries.has(key)) entries.set(key,[]);
        entries.get(key)!.push(entry);
      }
    } catch {}
  }
  return requests.map((request:any)=>{
    const entry=entries.get(`${request.method} ${request.url}`)?.shift();
    if (request.absoluteStart>0 && Number.isFinite(request.start) && request.start>=-10000) return request;
    const absoluteStart=Date.parse(entry?.startedDateTime);
    if (origin===null || !Number.isFinite(absoluteStart) || !(entry?.time>=0)) return {...request,start:null,end:null,timing_source:'unavailable'};
    return {...request,absoluteStart,absoluteEnd:absoluteStart+entry.time,start:absoluteStart-origin,end:absoluteStart+entry.time-origin,timing_source:'saved-HAR'};
  });
}
