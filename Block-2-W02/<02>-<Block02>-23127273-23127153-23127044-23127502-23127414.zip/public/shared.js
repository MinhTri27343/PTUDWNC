export const TIMEOUT_MS = 1000;
export class UpstreamError extends Error {
  constructor(code) { super(code); this.code = code; }
}
/** @param {string} url @param {any} options @param {any} onCall */
export async function readJson(url, options = {}, onCall = () => {}) {
  const start = Date.now();
  let status = 0;
  let bytes = 0;
  let code;
  try {
    const response = await fetch(url, { ...options, signal: AbortSignal.timeout(TIMEOUT_MS) });
    status = response.status;
    const body = await response.text();
    bytes = new TextEncoder().encode(body).byteLength;
    if (!response.ok) throw new UpstreamError(status === 404 ? 'RESOURCE_NOT_FOUND' : 'UPSTREAM_ERROR');
    return JSON.parse(body);
  } catch (error) {
    code = error instanceof UpstreamError ? error.code :
      error?.name === 'TimeoutError' || error?.name === 'AbortError' ? 'UPSTREAM_TIMEOUT' : 'UPSTREAM_ERROR';
    throw new UpstreamError(code);
  } finally {
    onCall({ start, end: Date.now(), status, bytes, code });
  }
}
/** @param {string} scope @param {any} error @param {string|undefined} resource_id */
export function partError(scope, error, resource_id = undefined) {
  const code = error?.code || 'UPSTREAM_ERROR';
  const labels = { user: 'thông tin người dùng', orders: 'danh sách đơn', product: 'thông tin sản phẩm' };
  const reason = code === 'UPSTREAM_TIMEOUT' ? 'Quá thời gian chờ.' :
    code === 'RESOURCE_NOT_FOUND' ? 'Dữ liệu không tồn tại.' : 'Service không khả dụng.';
  return { scope, ...(resource_id ? { resource_id } : {}), code,
    message: `Không tải được ${labels[scope]}. ${reason}` };
}
/** @param {any} user @param {any} orders @param {Map<string,any>} products @param {any[]} errors @param {string} client @returns {any} */
export function project(user, orders, products, errors, client) {
  const uniqueErrors = [...new Map(errors.map(error => [`${error.scope}:${error.resource_id || ''}`, error])).values()];
  const rows = orders === null ? null : orders.map(order => {
    const product = products.get(order.product_id) || null;
    return client === 'mobile' ? { id: order.id, status: order.status,
      product_name: product?.name ?? null, thumbnail_url: product?.thumbnail_url ?? null } : { ...order, product };
  });
  for (const error of uniqueErrors) if (error.scope === 'product') error.order_ids = (orders || []).filter(order => order.product_id === error.resource_id).map(order => order.id);
  return { ...(client === 'web' ? { user } : {}), orders: rows, errors: uniqueErrors };
}
/** @param {any} model @returns {string} */
export function resultState(model) {
  if (!model.errors.length) return 'complete';
  return model.orders === null && (!('user' in model) || model.user === null) ? 'failed' : 'partial';
}
