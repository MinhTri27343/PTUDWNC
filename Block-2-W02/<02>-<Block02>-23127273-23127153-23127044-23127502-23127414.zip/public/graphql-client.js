import {partError} from './shared.js';
export const queries={
 web:'query WebDashboard($user_id: ID!, $product_mode: ProductMode!) { user(id:$user_id) { id name } orders(user_id:$user_id,product_mode:$product_mode) { id user_id product_id quantity total_cents status created_at product { id name price_cents thumbnail_url } } }',
 mobile:'query MobileOrders($user_id: ID!, $product_mode: ProductMode!) { user(id:$user_id) { id } orders(user_id:$user_id,product_mode:$product_mode) { id status product { name thumbnail_url } } }'
};
/** @param {any} response @param {string} client */
export function graphQLModel(response,client){
 const data=response.data||{};
 const orders=data.orders??null;
 const errors=(response.errors||[]).map(error=>{
  const scope=error.extensions?.scope||(error.path?.[0]==='user'?'user':error.path?.[0]==='orders'&&error.path?.length>1?'product':'orders');
  const detail=partError(scope,{code:error.extensions?.code},error.extensions?.resource_id);
  if(scope==='product')detail.order_ids=orders?.filter((order,index)=>response.errors.some(issue=>issue.extensions?.resource_id===detail.resource_id&&issue.path?.[1]===index)).map(order=>order.id)||[];
  return detail;
 });
 const unique=[...new Map(errors.map(error=>[`${error.scope}:${error.resource_id||''}`,error])).values()];
 const priority={user:0,orders:1,product:2};
 unique.sort((a,b)=>priority[a.scope]-priority[b.scope]|| (orders?.findIndex(order=>a.order_ids?.includes(order.id))??0)-(orders?.findIndex(order=>b.order_ids?.includes(order.id))??0));
 return {...(client==='web'?{user:data.user??null}:{}),orders:orders===null?null:orders.map(order=>client==='web'?order:{id:order.id,status:order.status,product_name:order.product?.name??null,thumbnail_url:order.product?.thumbnail_url??null}),errors:unique};
}
export async function graphQLClient(uid,client,mode,runId){
 const response=await fetch(`/graphql?run_id=${encodeURIComponent(runId)}`,{method:'POST',headers:{'Content-Type':'application/json'},signal:AbortSignal.timeout(10000),body:JSON.stringify({query:queries[client],variables:{user_id:uid,product_mode:mode.toUpperCase()}})});
 const result=await response.json();
 if(!response.ok)throw new Error(result.errors?.[0]?.message||`GraphQL HTTP ${response.status}`);
 return graphQLModel(result,client);
}
