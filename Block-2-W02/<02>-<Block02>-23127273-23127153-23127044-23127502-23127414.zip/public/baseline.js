import { readJson, partError, project } from './shared.js';
/** @param {string} uid @param {string} client @param {string} runId */
export async function baseline(uid, client, runId) {
  let user = null;
  let orders = null;
  const products = new Map();
  const errors = [];
  const suffix = `run_id=${encodeURIComponent(runId)}`;
  try { user = await readJson(`http://localhost:3001/users/${encodeURIComponent(uid)}?${suffix}`); }
  catch (error) { errors.push(partError('user', error)); }
  try { orders = (await readJson(`http://localhost:3002/orders?user_id=${encodeURIComponent(uid)}&${suffix}`)).orders; }
  catch (error) { errors.push(partError('orders', error)); }
  for (const order of orders || []) {
    try { products.set(order.product_id, await readJson(`http://localhost:3003/products/${encodeURIComponent(order.product_id)}?${suffix}`)); }
    catch (error) { errors.push(partError('product', error, order.product_id)); }
  }
  return project(user, orders, products, errors, client);
}
