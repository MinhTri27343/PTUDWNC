import { statistics, selectedRows, compare, change } from './measurement-model.js';
const $=id=>document.getElementById(id);
const COLORS={baseline:'#4776cb',bff:'#138675','graphql-naive':'#9367bd','graphql-batched':'#c47f2e'};
const ALL=['baseline','bff','graphql-naive','graphql-batched'];
let variants=['baseline','bff'];
const LABELS={baseline:'Baseline',bff:'BFF','graphql-naive':'GraphQL naive','graphql-batched':'GraphQL batched'};
const STATES={complete:'Đầy đủ',partial:'Dữ liệu một phần',failed:'Thất bại'};
const SCENARIOS={healthy:'Service khỏe',slow:'Product chậm 300 ms',timeout:'Product vượt timeout',error:'Product trả 500',missing:'Thiếu product P1'};
const esc=value=>String(value ?? '').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const number=(value,decimals=0)=>Number.isFinite(value)?value.toLocaleString('vi-VN',{minimumFractionDigits:decimals,maximumFractionDigits:decimals}):'—';
const fmt=(value,unit='')=>`${number(unit==='KiB'?value/1024:value,unit==='ms'||unit==='KiB'?1:0)}${unit?' '+unit:''}`;
let data,kind=new URLSearchParams(location.search).get('kind')==='failure'?'failure':'healthy';
let selection,rows,source,allRows;
function stats(variant,metric){return statistics(rows.filter(row=>row.variant===variant).map(row=>row[metric]));}
function unavailable(){return '<p class="no-data">Chưa có đủ hai nhóm để so sánh.</p>';}
function pairChart(metric,unit='',title='') {
  const values=compare(rows,metric,variants);
  if(values.some(value=>value.median===undefined))return unavailable();
  const max=Math.max(1,...values.map(value=>value.max))*1.18;
  const x=value=>132+value/max*395;
  const ticks=Array.from({length:5},(_,i)=>max*i/4);
  return `<svg viewBox="0 0 620 ${values.length*45+55}" role="img" aria-label="${esc(title)}"><title>${esc(title)} — ${values.map(value=>`${LABELS[value.variant]} ${fmt(value.median,unit)}, min ${fmt(value.min,unit)}, max ${fmt(value.max,unit)}`).join('; ')}</title>${ticks.map(value=>`<line x1="${x(value)}" x2="${x(value)}" y1="15" y2="${values.length*45+10}" stroke="#e8edf3"/><text x="${x(value)}" y="${values.length*45+38}" text-anchor="middle" font-size="10" fill="#647487">${number(unit==='KiB'?value/1024:value,unit?1:0)}</text>`).join('')}${values.map((value,i)=>{const y=20+i*45;return `<text x="0" y="${y+16}" font-size="12" fill="#344b61">${LABELS[value.variant]}</text><rect x="132" y="${y}" width="${Math.max(0,x(value.median)-132)}" height="24" rx="3" fill="${COLORS[value.variant]}"/><line x1="${x(value.min)}" x2="${x(value.max)}" y1="${y+12}" y2="${y+12}" stroke="#182c41" stroke-width="1.5"/><line x1="${x(value.min)}" x2="${x(value.min)}" y1="${y+5}" y2="${y+19}" stroke="#182c41"/><line x1="${x(value.max)}" x2="${x(value.max)}" y1="${y+5}" y2="${y+19}" stroke="#182c41"/><text x="${Math.min(x(value.max)+8,535)}" y="${y+16}" font-size="12" font-weight="600" fill="#182c41">${fmt(value.median,unit)}</text>`;}).join('')}<text x="610" y="${values.length*45+38}" text-anchor="end" fill="#647487" font-size="10">${esc(unit||'lượt')}</text></svg>`;
}
function groupedChart(groups,title) {
 const values=groups.flatMap(group=>group.values);
 if(values.some(value=>value.median===undefined))return unavailable();
 const max=Math.max(1,...values.map(value=>value.max))*1.18;
 const y=value=>195-value/max*140;
 const groupWidth=510/groups.length;const width=Math.min(32,groupWidth/(variants.length+2));
 const legend=variants.map((variant,i)=>`<circle cx="${45+i*132}" cy="12" r="4" fill="${COLORS[variant]}"/><text x="${55+i*132}" y="16" font-size="10" fill="#647487">${LABELS[variant]}</text>`).join('');
 return `<svg viewBox="0 0 620 245" role="img" aria-label="${esc(title)}"><title>${esc(title)}: ${groups.map(group=>group.name+': '+group.values.map(value=>LABELS[value.variant]+' '+value.median).join(', ')).join('; ')}</title>${legend}${Array.from({length:4},(_,i)=>{const value=max*i/3;return `<line x1="40" x2="595" y1="${y(value)}" y2="${y(value)}" stroke="#e8edf3"/><text x="30" y="${y(value)+4}" font-size="10" text-anchor="end" fill="#647487">${number(value)}</text>`;}).join('')}${groups.map((group,g)=>{const center=65+groupWidth*(g+.5);return `${group.values.map((value,i)=>{const x=center-variants.length*(width+5)/2+i*(width+5);return `<rect x="${x}" y="${y(value.median)}" width="${width}" height="${195-y(value.median)}" rx="2" fill="${COLORS[value.variant]}"/><text x="${x+width/2}" y="${y(value.median)-8}" font-size="11" text-anchor="middle" fill="#182c41">${number(value.median)}</text>`;}).join('')}<text x="${center}" y="226" text-anchor="middle" font-size="12" fill="#344b61">${group.name}</text>`;}).join('')}</svg>`;
}
function serviceChart(suffix,title) {
 return groupedChart(['user','order','product'].map(service=>({name:service[0].toUpperCase()+service.slice(1),values:compare(rows,`${service}_${suffix}`,variants)})),title);
}
function scalingChart() {
 const groups=['small','large'].map(dataset=>({name:dataset==='small'?'5 đơn':'100 đơn',values:variants.map(variant=>({variant,...statistics(source.rows.filter(row=>row.client===selection.client&&row.mode===selection.mode&&row.scenario===selection.scenario&&row.state===selection.state&&row.dataset===dataset&&row.variant===variant).map(row=>row.product_queries))}))}));
 if(groups.flatMap(group=>group.values).some(value=>value.median===undefined))return '<p class="no-data">Bộ đo lỗi chỉ dùng 5 đơn.<br>Chọn “So sánh hiệu quả” để xem 5 → 100 đơn.</p>';
 return groupedChart(groups,'SQL Product khi số đơn tăng');
}
function kpi(metric,title,unit='') {
 const baseline=stats('baseline',metric);const focus=variants.includes('graphql-batched')?'graphql-batched':variants.includes('graphql-naive')?'graphql-naive':'bff';
 const target=stats(focus,metric);const delta=change(baseline?.median,target?.median);
 const label=delta===null?'Chưa đủ mẫu':Math.abs(delta)<.05?'Gần như không đổi':`${delta>0?'Giảm':'Tăng'} ${number(Math.abs(delta),1)}%`;
 return `<article class="kpi"><h3>${title}</h3>${variants.map(variant=>`<div class="metric-line"><span><i style="background:${COLORS[variant]}"></i>${LABELS[variant]}</span><strong>${fmt(stats(variant,metric)?.median,unit)}</strong></div>`).join('')}<span class="delta ${delta<0?'worse':delta===0?'same':''}">${label}</span><small>${LABELS[focus]} so với Baseline · median</small></article>`;
}
function graph(row) {
 const counts=['user','order','product'].map(service=>({service,calls:row[`${service}_requests`],sql:row[`${service}_queries`]}));
 const composed=row.variant!=='baseline';const serviceX=composed?335:300;
 const card=(x,y,w,h,label,sub,fill='#edf3f7')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="8" fill="${fill}"/><text x="${x+w/2}" y="${y+21}" text-anchor="middle" font-size="12" font-weight="600" fill="#182c41">${label}</text><text x="${x+w/2}" y="${y+39}" text-anchor="middle" font-size="10" fill="#647487">${sub}</text>`;
 const sub=row.variant==='bff'?'dedup + batch':row.variant==='graphql-naive'?'resolver · N+1':'DataLoader · batch';
 return `<svg viewBox="0 0 580 208" role="img" aria-label="Call graph ${LABELS[row.variant]}"><title>${LABELS[row.variant]}: browser API ${row.browser_api_requests}, ${counts.map(c=>`${c.service} ${c.calls} call / ${c.sql} SQL`).join('; ')}</title>${composed?`<path d="M99 101 L170 101" stroke="${COLORS[row.variant]}" stroke-width="1.5" marker-end="url(#arrow-${row.variant})"/>${card(170,75,115,52,row.variant==='bff'?'BFF':'GraphQL',sub,'#edf1f7')}`:''}<defs><marker id="arrow-${row.variant}" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0 0L7 3L0 6" fill="none" stroke="${COLORS[row.variant]}"/></marker></defs>${counts.map((c,i)=>`<path d="M${composed?285:100} 101 L${serviceX-7} ${i*62+37}" stroke="${COLORS[row.variant]}" stroke-width="1.5" fill="none" marker-end="url(#arrow-${row.variant})"/>${card(serviceX,i*62+10,225,52,`${c.service[0].toUpperCase()+c.service.slice(1)} Service`,`${number(c.calls)} call · ${number(c.sql)} SQL`)}`).join('')}${card(0,75,100,52,'Browser',`${number(row.browser_api_requests)} API`,'#edf1f7')}<text x="290" y="204" text-anchor="middle" fill="#647487" font-size="10">${composed?row.variant==='graphql-naive'?'User / Order song song; Product từng đơn song song':'User / Order song song; Product batch sau khi có đơn':'User → Order → Product theo từng đơn, tuần tự'}</text></svg>`;
}
function waterfall(row) {
 const requests=(row.requests||[]).filter(request=>request.api&&Number.isFinite(request.start)&&Number.isFinite(request.end)).sort((a,b)=>a.start-b.start);
 const max=Math.max(row.duration_ms,...requests.map(request=>request.end),1)*1.04;
 const x=value=>122+Math.max(0,value)/max*423;const height=45+requests.length*25;
 const label=request=>{const url=new URL(request.url);if(url.pathname==='/graphql')return 'GraphQL operation';if(url.pathname.startsWith('/bff/'))return 'BFF composition';if(url.pathname.startsWith('/users/'))return 'User';if(url.pathname==='/orders')return 'Order';return `Product ${url.pathname.split('/').at(-1)}`;};
 return `<svg viewBox="0 0 580 ${height}" role="img" aria-label="Waterfall ${LABELS[row.variant]} với mốc hoàn tất ${fmt(row.duration_ms,'ms')}"><title>${requests.length} API request; hoàn tất ${fmt(row.duration_ms,'ms')}. Cuộn xem tất cả request.</title>${Array.from({length:5},(_,i)=>{const value=max*i/4;return `<line x1="${x(value)}" x2="${x(value)}" y1="25" y2="${height}" stroke="#e3eaf1"/><text x="${x(value)}" y="17" text-anchor="middle" font-size="9" fill="#647487">${number(value,0)} ms</text>`;}).join('')}<line x1="${x(row.duration_ms)}" x2="${x(row.duration_ms)}" y1="24" y2="${height}" stroke="#d57b3b" stroke-width="2"/>${requests.map((request,i)=>{const y=35+i*25;return `<text x="8" y="${y+10}" font-size="10" fill="#344b61">${esc(label(request))}</text><rect x="${x(request.start)}" y="${y}" width="${Math.max(.8,x(request.end)-x(request.start))}" height="13" rx="2" fill="${request.status===0||request.status>=400?'#b85e60':COLORS[row.variant]}"><title>${esc(label(request))} · ${request.status||'timeout'} · ${fmt(request.end-request.start,'ms')}</title></rect>`;}).join('')}</svg>`;
}
function callWaterfall(row){
 const reference=(row.requests||[]).find(request=>request.api&&request.absoluteStart>0&&Number.isFinite(request.start));
 if(!reference)return unavailable();
 const origin=reference.absoluteStart-reference.start;
 const internal={...row,requests:(row.calls||[]).map(call=>({api:true,url:'http://localhost'+call.route,status:call.status,start:call.start-origin,end:call.end-origin}))};
 return waterfall(internal);
}
function renderTraces() {
  const iteration=Number($('trace-iteration').value);
  const pair=variants.map(variant=>rows.find(row=>row.variant===variant&&row.iteration===iteration));
  $('traces').innerHTML=pair.map(row=>row?`<article class="panel trace-panel"><div class="trace-head"><i style="width:9px;height:9px;border-radius:3px;background:${COLORS[row.variant]}"></i><strong>${LABELS[row.variant]}</strong><span>${fmt(row.duration_ms,'ms')}</span></div>${graph(row)}<h4>Waterfall browser · ${row.browser_api_requests} API request</h4><div class="waterfall">${waterfall(row)}</div>${row.variant!=='baseline'?`<h4>Trace nội bộ · ${row.calls?.length||0} call tới service</h4><div class="waterfall">${callWaterfall(row)}</div>`:''}<div class="axis-legend"><span>0 ms = API đầu tiên</span><span style="color:#a76332">│ Màn hình hoàn tất</span></div><div class="trace-meta"><a href="/evidence/${source.name}/${row.run_id}.har">Mở HAR</a><a href="/evidence/${source.name}/${row.run_id}.model.json">Response đã ghép</a><br>${esc(row.run_id)}</div></article>`:'<article class="panel">Không có lượt tương ứng.</article>').join('');
  $('failure-outcome').hidden=kind!=='failure';
  $('failure-outcome').innerHTML=kind==='failure'?pair.map(row=>`<article><h3>${LABELS[row?.variant]} · ${STATES[row?.state]||'Chưa có mẫu'}</h3>${row?.outcome?`<p><strong>${number(row.outcome.orders)} đơn giữ lại</strong> · ${number(row.outcome.missingProducts)} đơn thiếu thông tin product.</p><p>${row.outcome.errors?.length?row.outcome.errors.map(error=>`<code>${esc(error.resource_id||error.scope)}: ${esc(error.code)}</code>`).join(' '):'Không có lỗi upstream trong response.'}</p><p>Dữ liệu chưa lấy được là null; lỗi nằm tại phần product tương ứng, không tạo tên hoặc giá giả.</p>`:'<p>Chưa có model lưu cho lượt này.</p>'}</article>`).join(''):'';
}
function render() {
  source=data.sources[kind];
  variants=ALL.filter(variant=>source?.rows.some(row=>row.variant===variant)&&(!variant.startsWith('graphql')||$('graphql-display').value==='both'||variant===`graphql-${$('graphql-display').value}`));
  const hasSource=!!source;
  $('empty').hidden=hasSource;$('content').hidden=!hasSource;
  for(const type of ['healthy','failure']){$(`tab-${type}`).setAttribute('aria-selected',String(type===kind));$(`tab-${type}`).disabled=!data.sources[type];}
  $('scenario-label').hidden=kind!=='failure';
  $('dataset').disabled=kind==='failure';$('mode').disabled=kind==='failure';
  if(!source){$('sample-total').textContent='Chưa có bộ đo';return;}
  if(kind==='failure'){$('dataset').value='small';$('mode').value='warm';}
  const scenario=kind==='healthy'?'healthy':$('scenario').value;
  const states=[...new Set(source.rows.filter(row=>row.scenario===scenario&&row.client===$('client').value&&row.dataset===$('dataset').value&&row.mode===$('mode').value).map(row=>row.state))];
  const previous=$('result-state').value;
  $('result-state').innerHTML=states.map(state=>`<option value="${state}">${STATES[state]||esc(state)}</option>`).join('');
  if(states.includes(previous))$('result-state').value=previous;
  selection={scenario,client:$('client').value,dataset:$('dataset').value,mode:$('mode').value,state:$('result-state').value};
  allRows=selectedRows(source.rows,selection);
  rows=allRows.filter(row=>variants.includes(row.variant));
  const n=variants.map(variant=>rows.filter(row=>row.variant===variant).length);
  $('sample-total').textContent=`${Object.values(data.sources).reduce((sum,entry)=>sum+entry.samples,0)} lượt đo đã lưu`;
  $('source-date').textContent=`Bộ đang xem: ${source.samples} mẫu · ${new Date(source.created).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'})}`;
  $('selection-context').textContent=`${SCENARIOS[scenario]} · ${selection.client==='web'?'Web':'Mobile'} · ${selection.dataset==='large'?'100':'5'} đơn · ${selection.mode==='warm'?'Ấm':'Lạnh'} · ${STATES[selection.state]} · ${variants.map((variant,index)=>n[index]+' mẫu '+LABELS[variant]).join(' / ')}`;
  $('notice').hidden=n.every(count=>count>=5);
  $('notice').textContent='Nhóm này chưa đủ 5 mẫu mỗi luồng; tránh kết luận từ bộ đo thiếu.';
  $('series-legend').innerHTML=variants.map(variant=>`<span><i style="background:${COLORS[variant]}"></i>${LABELS[variant]}</span>`).join('');
  $('kpis').innerHTML=kpi('browser_api_requests','Request API browser')+kpi('db_queries','Tổng SQL đọc')+kpi('duration_ms','Hoàn tất màn hình','ms')+kpi('api_bytes','Payload API','KiB');
  $('chart-browser').innerHTML=pairChart('browser_api_requests','','Request API browser');
  $('chart-time').innerHTML=pairChart('duration_ms','ms','Thời gian màn hình hoàn tất');
  $('chart-services').innerHTML=serviceChart('requests','Call nhận tại từng service');
  $('chart-sql').innerHTML=serviceChart('queries','SQL từng service');
  $('chart-payload').innerHTML=pairChart('api_bytes','KiB','Payload API browser nhận');
  $('chart-scale').innerHTML=scalingChart();
  const a=stats('baseline','duration_ms'),b=stats('bff','duration_ms');
  const timeDelta=change(a?.median,b?.median);
  const apiA=stats('baseline','browser_api_requests'),apiB=stats('bff','browser_api_requests');
  const productA=stats('baseline','product_queries'),productB=stats('bff','product_queries');
  const bytesA=stats('baseline','api_bytes'),bytesB=stats('bff','api_bytes');
  $('takeaway-title').textContent=kind==='failure'?scenario==='slow'?'Gom lượt gọi giúp tránh chờ nối tiếp.':scenario==='timeout'?'Giữ đơn, đánh dấu lỗi phần product.':'Lỗi product không làm mất danh sách đơn.':timeDelta>1?'BFF rút ngắn thời gian ở nhóm này.':timeDelta<-1?'Ít request hơn, nhưng nhóm này chưa nhanh hơn.':'Ít request hơn; thời gian gần tương đương.';
  const naive=statistics(allRows.filter(row=>row.variant==='graphql-naive').map(row=>row.product_queries)),batched=statistics(allRows.filter(row=>row.variant==='graphql-batched').map(row=>row.product_queries));
  $('takeaway-text').innerHTML=`<ul><li><strong>Composition:</strong> Baseline ${fmt(apiA?.median)} request; BFF ${fmt(apiB?.median)} request${variants.some(variant=>variant.startsWith('graphql'))?', GraphQL 1 operation':''}; dữ liệu được ghép ${kind==='healthy'?'trên server':'và lỗi được đánh dấu theo từng phần'}.</li><li><strong>Batch/dedup:</strong> SQL Product ${fmt(productA?.median)} → ${fmt(productB?.median)}. ${scenario==='error'?'Product trả lỗi trước khi chạm DB.':'Đây là tối ưu nội bộ, ngoài việc browser gọi một endpoint BFF.'}</li><li><strong>Trải nghiệm:</strong> Baseline ${fmt(a?.median,'ms')} → BFF ${fmt(b?.median,'ms')}. ${variants.filter(variant=>variant.startsWith('graphql')).map(variant=>LABELS[variant]+' '+fmt(stats(variant,'duration_ms')?.median,'ms')).join(' · ')}. ${timeDelta>1?'BFF có median nhanh hơn '+number(timeDelta,1)+'% so với Baseline.':timeDelta<-1?'Nhóm này chậm hơn '+number(-timeDelta,1)+'%; không coi giảm call là đảm bảo giảm thời gian.':'Mức chênh lệch nhỏ; đọc cả khoảng min–max.'}</li>${naive&&batched?`<li><strong>GraphQL:</strong> naive ${fmt(naive.median)} → batched ${fmt(batched.median)} SQL Product; cùng một operation ở browser, khác chiến lược resolver.</li>`:''}</ul>`;
  $('internal-calls').textContent=variants.filter(variant=>variant!=='baseline').map(variant=>`${LABELS[variant]} → service: ${fmt(stats(variant,'service_calls')?.median)} call`).join(' · ')+'. Baseline gọi trực tiếp từ browser.';
  $('payload-note').textContent=bytesB?.median>bytesA?.median?(selection.state!=='complete'?'Payload BFF lớn hơn ở nhóm lỗi này: response ghép chứa thêm lỗi có cấu trúc. Timeout ở baseline có thể không nhận body Product.':'Payload BFF lớn hơn ở nhóm này. Web giữ đủ dữ liệu đơn và lặp object product trong response ghép.'):selection.client==='mobile'?'Mobile: BFF dùng DTO gọn, GraphQL chọn trường bằng query. Baseline vẫn nhận tài nguyên đầy đủ từ service.':'Body JSON không gồm header hay tài nguyên tĩnh; ít request không đồng nghĩa payload luôn nhỏ hơn.';
  const iterations=[...new Set(rows.map(row=>row.iteration))].sort((a,b)=>a-b);
  const previousIteration=Number($('trace-iteration').value);
  $('trace-iteration').innerHTML=iterations.map(value=>`<option value="${value}">Lượt ${value}</option>`).join('');
  $('trace-iteration').value=String(iterations.includes(previousIteration)?previousIteration:iterations[0]);
  renderTraces();
  const base=`/evidence/${source.name}`;
  $('artifact-links').innerHTML=[['raw.csv','CSV toàn bộ mẫu'],['raw.json','JSON toàn bộ mẫu'],['logs.jsonl','Log SQL / call'],['equality.json','Đối chiếu model'],['report.html','Báo cáo chi tiết gốc']].map(([file,label])=>`<a href="${base}/${file}">${label}</a>`).join('');
  $('raw-rows').innerHTML=rows.map(row=>`<tr><td>${LABELS[row.variant]} / ${row.iteration}</td><td>${STATES[row.state]}</td><td>${number(row.duration_ms,1)}</td><td>${row.browser_api_requests}</td><td>${row.user_requests}/${row.order_requests}/${row.product_requests}</td><td>${row.user_queries}/${row.order_queries}/${row.product_queries}</td><td>${number(row.api_bytes)}</td><td><a href="${base}/${row.run_id}.har">HAR</a></td></tr>`).join('');
  $('environment').textContent=`${source.environment.node} · Chromium ${source.environment.chromium} · ${source.environment.platform}/${source.environment.arch} · ${source.environment.network}. ${source.equalityCount!==null?source.equalityCount+' đối chiếu model thành công trong bộ đo.':''} Byte upstream và tài nguyên tĩnh được ghi riêng trong CSV/JSON. Mẫu timeout bao gồm SQL upstream chạy sau abort; thời gian chờ collector không nằm trong thời gian màn hình.`;
  document.body.dataset.ready='true';
}
for(const id of ['scenario','client','dataset','mode','result-state','graphql-display'])$(id).addEventListener('change',render);
$('trace-iteration').addEventListener('change',renderTraces);
for(const button of document.querySelectorAll('[data-kind]'))button.addEventListener('click',()=>{kind=button.dataset.kind;if(kind==='healthy'){$('dataset').value='large';$('mode').value='warm';}history.replaceState(null,'',`/measurements?kind=${kind}`);render();});
try {
  const response=await fetch('/measurements/data');
  if(!response.ok)throw new Error(`HTTP ${response.status}`);
  data=await response.json();
  if(!data.sources[kind])kind=Object.keys(data.sources)[0]||kind;
  render();
} catch(error) {
  $('sample-total').textContent='Không tải được số đo';$('notice').hidden=false;
  $('notice').textContent=`Không tải được báo cáo: ${error.message}. Hãy tải lại trang.`;
}
