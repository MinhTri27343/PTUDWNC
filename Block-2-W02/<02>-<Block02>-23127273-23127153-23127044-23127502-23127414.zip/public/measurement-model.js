/** @param {number[]} values */
export function statistics(values) {
  const sorted = values.filter(Number.isFinite).sort((a,b)=>a-b);
  if (!sorted.length) return null;
  const middle=Math.floor(sorted.length/2);
  return {median:sorted.length%2?sorted[middle]:(sorted[middle-1]+sorted[middle])/2,min:sorted[0],max:sorted.at(-1),count:sorted.length};
}
/** @param {any[]} rows @param {any} selection */
export function selectedRows(rows, selection) {
  return rows.filter(row=>['scenario','client','dataset','mode','state'].every(key=>row[key]===selection[key]));
}
/** @param {any[]} rows @param {string} metric */
export function compare(rows, metric, variants=['baseline','bff']) {
  return variants.map(variant=>({variant,...statistics(rows.filter(row=>row.variant===variant).map(row=>row[metric]))}));
}
/** @param {number} baseline @param {number} bff */
export function change(baseline,bff) {
  if (!Number.isFinite(baseline)||!Number.isFinite(bff)||baseline===0) return null;
  return (baseline-bff)/baseline*100;
}
