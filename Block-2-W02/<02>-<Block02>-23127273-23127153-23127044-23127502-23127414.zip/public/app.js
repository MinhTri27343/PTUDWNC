import { baseline } from './baseline.js';
import { graphQLClient } from './graphql-client.js';
import { resultState } from './shared.js';
const screen = document.querySelector('#screen');
const controls = document.querySelector('#controls');
const variant = document.querySelector('#variant');
const client = document.querySelector('#client');
const uid = document.querySelector('#userId');
function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}
function showError(error) {
  const node = element('div', error.message, 'error');
  node.append(element('small', error.code));
  node.dataset.errorScope = error.scope;
  return node;
}
function render(model, mode) {
  screen.replaceChildren();
  screen.className = mode;
  if (mode === 'web') {
    const section = element('section', undefined, 'user');
    if (model.user) section.append(element('strong', model.user.name));
    else section.append(showError(model.errors.find(error => error.scope === 'user')));
    screen.append(section);
  } else for (const error of model.errors.filter(error => error.scope === 'user')) screen.append(showError(error));
  if (model.orders === null) { screen.append(showError(model.errors.find(error => error.scope === 'orders'))); return; }
  if (!model.orders.length) { screen.append(element('div', 'Chưa có đơn', 'empty')); return; }
  const list = element('div', undefined, 'orders');
  for (const order of model.orders) {
    const card = element('article', undefined, 'order');
    card.dataset.orderId = order.id;
    const productName = mode === 'web' ? order.product?.name : order.product_name;
    const thumbnail = mode === 'web' ? order.product?.thumbnail_url : order.thumbnail_url;
    if (thumbnail) { const img = element('img'); img.src = thumbnail; img.alt = productName; card.append(img); }
    const info = element('div', undefined, 'info');
    info.append(element('span', `${order.id} · ${order.status}`, 'status'));
    if (productName) info.append(element('h3', productName));
    else {
      const error = model.errors.find(error => error.scope === 'product' && error.order_ids?.includes(order.id));
      info.append(showError(error));
    }
    if (mode === 'web') info.append(element('div', `User ${order.user_id} · Product ${order.product_id} · Số lượng ${order.quantity}\nTổng tiền: ${(order.total_cents / 100).toLocaleString('vi-VN')} · ${order.created_at}`, 'meta'));
    card.append(info); list.append(card);
  }
  screen.append(list);
}
let configured=null,comparing=false;
const autorun=new URLSearchParams(location.search).get('autorun')==='1';
const dataset=document.querySelector('#demo-dataset');
const scenario=document.querySelector('#demo-scenario');
const graphqlMode=document.querySelector('#graphql-mode');
variant.addEventListener('change',()=>{document.querySelector('#graphql-mode-label').hidden=variant.value!=='graphql';});
async function configure(){
 if(autorun)return;
 const desired={dataset:dataset.value,scenario:scenario.value};
 if(configured?.dataset===desired.dataset&&configured?.scenario===desired.scenario)return;
 document.querySelector('#state').textContent='Đang áp dụng dữ liệu / tình huống…';
 const response=await fetch('/demo/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(desired)});
 const result=await response.json();if(!response.ok)throw new Error(result.message);configured=result;
}
async function load(runOverride) {
  const runId = runOverride || new URLSearchParams(location.search).get('run_id') || crypto.randomUUID();
  const choice={variant:variant.value,client:client.value,userId:uid.value,mode:graphqlMode.value};
  controls.querySelectorAll('button,select,input').forEach(control=>control.disabled=true);
  screen.replaceChildren(element('p', 'Đang tải…'));
  screen.dataset.state = 'loading';
  document.querySelector('#state').textContent = 'Đang tải';
  window.demoResult = undefined;
  try {
    await configure();
    performance.clearMarks(); performance.clearMeasures();
    performance.mark('screen-start');
    let model;
    if (choice.variant === 'baseline') model = await baseline(choice.userId, choice.client, runId);
    else if(choice.variant==='graphql')model=await graphQLClient(choice.userId,choice.client,choice.mode,runId);
    else {
      const route = choice.client === 'web' ? 'web/dashboard' : 'mobile/orders';
      const response = await fetch(`/bff/${route}?user_id=${encodeURIComponent(choice.userId)}&run_id=${encodeURIComponent(runId)}`);
      if (!response.ok) throw new Error(`BFF HTTP ${response.status}`);
      model = await response.json();
    }
    render(model, choice.client);
    await Promise.all([...screen.querySelectorAll('img')].map(async img => {
      try { await img.decode(); } catch { img.replaceWith(element('div', 'Không tải được thumbnail.', 'error')); }
    }));
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    performance.mark('screen-complete');
    const duration = performance.measure('screen-duration', 'screen-start', 'screen-complete').duration;
    const state = resultState(model);
    window.demoResult = { model, state, duration, run_id:runId, variant:choice.variant==='graphql'?`graphql-${choice.mode}`:choice.variant, start:performance.getEntriesByName('screen-start')[0].startTime };
    document.querySelector('#state').textContent = {complete:'Đầy đủ',partial:'Dữ liệu một phần',failed:'Không tải được dữ liệu'}[state];
    document.querySelector('#elapsed').textContent = `${duration.toFixed(1)} ms · ${model.errors.length} lỗi`;
    screen.dataset.state = 'ready';
  } catch (error) {
    screen.replaceChildren(element('div', error.message, 'error'));
    screen.dataset.state = 'failed';
    window.demoResult = { state:'failed', error:error.message };
    document.querySelector('#state').textContent = 'Lỗi ứng dụng';
  } finally { controls.querySelectorAll('button,select,input').forEach(control=>control.disabled=comparing); }
}
controls.addEventListener('submit', event => { event.preventDefault(); document.querySelector('#live-comparison').hidden=true;void load(); });
const parameters = new URLSearchParams(location.search);
if (parameters.get('variant')) variant.value = parameters.get('variant');
if (parameters.get('client')) client.value = parameters.get('client');
if (parameters.get('user_id')) uid.value = parameters.get('user_id');
if(parameters.get('graphql_mode'))graphqlMode.value=parameters.get('graphql_mode');
document.querySelector('#graphql-mode-label').hidden=variant.value!=='graphql';
if(autorun)void load();
else fetch('/demo/settings').then(response=>response.json()).then(settings=>{configured=settings;dataset.value=settings.dataset;scenario.value=settings.scenario;}).catch(()=>{});

// One browser run per variant, using the same configuration. This is a live demo, not the five-sample evidence matrix.
document.querySelector('#compare-live').addEventListener('click',async()=>{
 if(comparing||!controls.reportValidity())return;window.liveComparison=undefined;comparing=true;controls.querySelectorAll('button,select,input').forEach(control=>control.disabled=true);
 const box=document.querySelector('#live-comparison');box.hidden=false;
 box.replaceChildren(element('p','Đang đo Baseline → BFF → GraphQL naive → GraphQL batched…'));
 const original={variant:variant.value,mode:graphqlMode.value};const measurements=[];
 try{
  await configure();
  for(const option of ['baseline','bff','graphql-naive','graphql-batched']){
   variant.value=option.startsWith('graphql')?'graphql':option;graphqlMode.value=option.endsWith('naive')?'naive':'batched';
   document.querySelector('#graphql-mode-label').hidden=variant.value!=='graphql';
   await load(crypto.randomUUID());
   if(!window.demoResult?.model)throw new Error(window.demoResult?.error||'Không tải được màn hình.');
   await new Promise(resolve=>setTimeout(resolve,scenario.value==='timeout'?1700:60));
   const response=await fetch(`/demo/metrics?run_id=${window.demoResult.run_id}`);const metrics=await response.json();
   if(!response.ok)throw new Error(metrics.message);
   measurements.push({...metrics,...window.demoResult});
   box.replaceChildren(element('p',`Đã đo ${measurements.length}/4 biến thể…`));
  }
  const heading=element('h2','So sánh nhanh trên browser hiện tại');
  const note=element('p','Mỗi biến thể 1 lượt, cùng dataset/client/tình huống. Bộ đo 5 lượt/cell và median/min–max nằm trong Dashboard đo.');
  const table=element('table');const header=element('tr');
  for(const label of ['Phương pháp','Hoàn tất (ms)','Browser API','Call Product','SQL tổng','Payload JSON (byte)','Kết quả'])header.append(element('th',label));table.append(header);
  const labels={baseline:'Baseline',bff:'BFF','graphql-naive':'GraphQL · naive','graphql-batched':'GraphQL · batched'};
  for(const row of measurements){const tr=element('tr');for(const value of [labels[row.variant],row.duration.toFixed(1),row.browser_api_requests,row.product_requests,row.db_queries,row.api_bytes,row.state])tr.append(element('td',String(value)));table.append(tr);}
  box.replaceChildren(heading,note,table);window.liveComparison=measurements;
 }catch(error){box.replaceChildren(element('div',error.message,'error'));}
 finally{variant.value=original.variant;graphqlMode.value=original.mode;document.querySelector('#graphql-mode-label').hidden=variant.value!=='graphql';comparing=false;controls.querySelectorAll('button,select,input').forEach(control=>control.disabled=false);}
});
