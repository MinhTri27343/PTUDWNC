# Kết quả tích hợp — 08/10/2026

Cả Baseline, BFF, GraphQL naive và GraphQL batched chạy trong Block-2-W02 với cùng dữ liệu/REST/SQLite/UI/harness. Đã chạy160 mẫu healthy và160 mẫu failure, mỗi cell5 lượt. 22 tests qua; GraphQL/controller suite8 tests đã chạy lại sau thay đổi guard UI. Typecheck qua.

## 100 đơn, warm

| Client / biến thể | Median ms [min–max] | Browser API | SQL Product | Tổng SQL | API bytes |
|---|---:|---:|---:|---:|---:|
| web / baseline | 118.7 [118.5–168.2] | 102 | 100 | 102 | 22389 |
| mobile / baseline | 103.7 [101.9–119.1] | 102 | 100 | 102 | 22389 |
| web / bff | 35.9 [35.3–52.0] | 1 | 1 | 3 | 23509 |
| mobile / bff | 35.2 [34.5–35.8] | 1 | 1 | 3 | 9283 |
| web / graphql-naive | 52.3 [51.7–69.5] | 1 | 100 | 102 | 23506 |
| mobile / graphql-naive | 52.2 [51.6–52.7] | 1 | 100 | 102 | 9699 |
| web / graphql-batched | 52.0 [35.1–52.3] | 1 | 1 | 3 | 23506 |
| mobile / graphql-batched | 35.8 [34.8–36.5] | 1 | 1 | 3 | 9699 |

GraphQL naive vẫn N+1 dù browser chỉ1 operation. BFF/GraphQL batched chỉ1 call/SQL Product với cả5/100 đơn. Naive gọi song song nên thời gian không tăng tuyến tính theo call count. GraphQL có parse/execute/serialization overhead; batched không được bảo đảm luôn nhanh nhất. Web payload có thể lớn hơn baseline do shape ghép/envelope; mobile dùng DTO/query gọn.

## Product timeout — small/warm

| Biến thể / client | Median ms | Trạng thái |
|---|---:|---|
| baseline / web | 5035.1 | partial |
| baseline / mobile | 5035.1 | partial |
| bff / web | 1035.5 | partial |
| bff / mobile | 1035.3 | partial |
| graphql-naive / web | 1036.1 | partial |
| graphql-naive / mobile | 1035.5 | partial |
| graphql-batched / web | 1036.5 | partial |
| graphql-batched / mobile | 1035.5 | partial |

Giữ đơn và tổng tiền, product null/lỗi tại card. Baseline chờ5 timeout tuần tự; GraphQL naive chờ5 call song song; BFF/GraphQL batched chờ1 batch. SQL sau abort vẫn được đếm, collector chờ ngoài duration. Model và lỗi của cả4 biến thể khớp.

## Evidence cuối

- [Healthy160 mẫu](evidence/healthy-2026-10-08T04-02-09-887Z/report.html).
- [Failure160 mẫu](evidence/failure-2026-10-08T04-06-11-022Z/report.html).
- [Dashboard trên localhost](http://localhost:3000/measurements): biểu đồ, mode filter và trace N+1 nội bộ.
- [Demo/so sánh nhanh](http://localhost:3000): mode/dataset/lỗi chọn bằng UI; một lượt mỗi biến thể, không thay median5 mẫu.

Artifacts local được gitignore; đính kèm thư mục evidence khi nộp. Các báo cáo80 mẫu cũ chỉ có baseline/BFF, không dùng so sánh GraphQL tích hợp. Bản gốc Block-2 cũng có schema/harness khác nên không trộn số đo.

Giới hạn: localhost, mobile mô phỏng browser, không throttling/compression/cache liên request, thứ tự cố định, restart không xóa OS disk cache.
