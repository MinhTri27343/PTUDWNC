# Plan — Baseline và BFF

Chốt trước khi triển khai: Node 22, TypeScript, Express 5, better-sqlite3; ba process User/Order/Product với ba SQLite riêng; BFF gọi HTTP. Không GraphQL, Docker, ORM, auth, cache liên request hoặc Prometheus/Grafana. UI HTML/CSS/JS dùng chung render và projection.

Schema: users(id,name); orders(id,user_id,product_id,quantity,total_cents,status,created_at); products(id,name,price_cents,thumbnail_url). Seed cố định small=5 đơn (P1/P2/P1/P3/P2), large=100 đơn lặp P1–P5; DB có 5 product. Giá tổng đơn lưu độc lập.

Baseline: User → Order → từng Product tuần tự, kể cả lặp. BFF: User/Order song song allSettled → Set ID → Product batch với một SQL IN → Map giữ thứ tự. Mobile chỉ id,status,product_name,thumbnail_url, metadata errors ở cấp response.

Policy: partial HTTP 200, null cho dữ liệu lỗi; errors có scope/resource_id/code/message. User lỗi vẫn lấy đơn; Order lỗi orders=null, khác []; Product lỗi giữ đơn và đánh dấu vùng product. Không giả tên/giá/ảnh, không dùng kết quả cũ. Timeout upstream 1000ms, không retry. Input sai 400, lỗi BFF ngoài dự kiến 500.

Đo: Playwright Chromium HAR/timing và Performance marks; Pino JSONL request/service_call/db_query có run_id. API browser truyền run_id query, BFF header. SQL đếm tại wrapper get/all, bỏ setup/health. Payload byte JSON UTF-8 không nén; upstream/static riêng. Hoàn tất sau DOM, ảnh decode và render; complete/partial/failed tách nhóm.

Ma trận healthy: 2 variant × 2 client × 2 dataset × 2 cold/warm × 5=80. Cold restart mỗi mẫu, health không DB; warm một lượt không tính rồi 5 mẫu. Context mới, no-store, tuần tự. Failure small: delay300/timeout1500/500/missing × 2 variant × 2 client × 5=80. User/Order/all down kiểm tra thêm.

Artifact: raw CSV/JSON, HAR, JSONL, HTML median/min/max, waterfall completion marker, call graph, equality evidence, environment và limitations. Không ép tốc độ phải tốt hơn.

Thứ tự: plan → seed/runner → baseline → BFF → đo/report → test/full measure/README. Acceptance: equality hai client; mobile đúng fields; BFF Product1call/1SQL với 5/100; empty; missing; từng upstream lỗi; UI đúng vùng; counter/80mẫu/artifact đầy đủ. Giữ Block1.

## Tích hợp GraphQL theo yêu cầu mới

GraphQL dùng chung User/Order/Product và SQLite của Block-2-W02; POST /graphql ở cổng3000. Hai query web/mobile dùng root user và orders độc lập để giữ partial data khi User lỗi. Product nullable, lỗi có path/extensions. Mode NAIVE/BATCHED là biến query, UI chọn theo request; DataLoader theo operation, không cache xuyên request. Browser normalize GraphQL response về cùng view model để đối chiếu.

UI chọn dataset5/100, Product healthy/slow/timeout/error/missing và GraphQL naive/batched. Runner dev nhận IPC cấu hình từ app, dừng ba data service trước seed/restart; app3000 giữ kết nối trả kết quả. Thao tác đổi cấu hình nằm trước mốc đo màn hình.

Đo chung bốn biến thể baseline,bff,graphql-naive,graphql-batched (ba phương pháp, hai mode GraphQL), cùng seed/fields/image decode/cold-warm/policy. Healthy160 mẫu và failure160 mẫu, 5 lượt/cell. Dashboard màu riêng từng biến thể, lọc mode GraphQL và trace/SQL/median/minmax cùng nhóm. Có đo nhanh trên UI bằng browser hiện tại, lấy counters runner theo run_id; số đo nhanh không thay bộ Playwright160 mẫu.
