# Báo cáo Block 2: API composition

**Baseline · BFF · GraphQL naive/batched**

Ngày tổng hợp: **08/10/2026**. Module nộp bài: **Block-2-W02/**. Báo cáo giải thích quyết định của nhóm và kết quả thực nghiệm của hệ thống tích hợp cuối cùng. Số liệu được lấy từ các lần chạy thật; lý do chọn công nghệ là đánh giá của nhóm theo phạm vi bài tập, không phải kết quả benchmark giữa các framework.

## 1. Bài toán và tiêu chí hoàn thành

Dashboard cần tên người dùng, danh sách đơn và thông tin product. Dữ liệu thuộc ba service User, Order, Product; mỗi service có CSDL riêng. Nếu browser tự gọi và ghép dữ liệu, màn hình phụ thuộc nhiều request và thứ tự hoàn tất của chúng.

Nhóm xây dựng ba phương pháp trên cùng dữ liệu: baseline gọi REST tuần tự từ browser, BFF ghép trên server bằng endpoint theo client, và GraphQL để client chọn trường. GraphQL có hai biến thể để tái hiện N+1 trước khi sửa bằng batching/dedup. Vì vậy, bảng đo có **bốn biến thể của ba phương pháp**.

Tiêu chí hoàn thành gồm dữ liệu hiển thị khớp cho web/mobile; số request, call và SQL được đếm độc lập; có dataset nhỏ/lớn; có waterfall và mốc render xong; có dữ liệu thô của ít nhất 5 lần mỗi nhóm; và có cùng policy dữ liệu một phần khi upstream chậm hoặc lỗi. Nguồn yêu cầu: [Bài tập API composition, tuần 2](https://pub.nndkhoa9.win/webadv/w2/block-02-assignment.html).

## 2. Kiến trúc và phạm vi cuối cùng

Ba service REST chạy ở cổng 3001–3003 với các file SQLite riêng. App ở cổng 3000 phục vụ UI, BFF, GraphQL và dashboard đo. BFF/GraphQL chỉ gọi HTTP tới service; quyền đọc CSDL vẫn thuộc từng service. App dùng chung process cho BFF và GraphQL để giảm thao tác setup, nhưng giữ các handler và luồng composition riêng.

| Thành phần | Vai trò | Quyền truy cập dữ liệu |
|---|---|---|
| Browser | Chọn phương pháp/client/mode/dataset/lỗi; render cùng view model | Gọi HTTP; không đọc SQLite |
| User Service | Tìm người dùng | Chỉ user.db |
| Order Service | Lấy đơn theo user | Chỉ order.db |
| Product Service | Lấy một product hoặc một batch | Chỉ product.db |
| BFF | Ghép User/Order/Product; chọn DTO web/mobile | HTTP tới ba service |
| GraphQL | Thực thi query và resolver; naive hoặc DataLoader | HTTP tới ba service |
| Runner | Khởi động/dừng process, seed, thu log và điều khiển demo | Quản lý dữ liệu giả khi data service đã dừng |

Bản GraphQL gốc từ nhánh feat/graphql được giữ trong Block-2/ để tham khảo. So sánh cuối cùng chỉ dùng Block-2-W02/, bởi module gốc có seed, contract và định nghĩa thời điểm hoàn tất khác. Nhóm đã thống nhất các yếu tố này trước khi đo lại cả ba phương pháp.

## 3. Vì sao chọn stack hiện tại?

### 3.1 Node.js 22 + TypeScript + Express 5

Nhóm chọn cùng hệ sinh thái với Block 1 để giảm thời gian làm quen và dành thời gian cho composition, resolver, lỗi và evidence. TypeScript kiểm tra các interface của code server/runner; Express cung cấp routing và middleware đủ cho các REST service và POST /graphql. [Tài liệu Express](https://expressjs.com/) mô tả lớp routing/middleware tối giản phù hợp với cách tổ chức này.

Spring Boot, ASP.NET Core hoặc NestJS đều có thể giải bài toán. Nhóm không chọn chúng cho phiên bản này vì phải bổ sung runtime hoặc mô hình framework khác so với code đang có; những lợi ích như dependency injection và cấu trúc ứng dụng lớn chưa phải mục tiêu chính của lab. Đây là lựa chọn về chi phí triển khai và khả năng giải thích code, **không phải kết luận Express nhanh hơn các framework đó**.

Đánh đổi: Express không áp đặt nhiều cấu trúc. Nhóm phải tự tổ chức validation, timeout, log và error mapping; TypeScript không thay thế validation runtime của HTTP request.

### 3.2 SQLite + better-sqlite3 + SQL thuần

Nhóm chọn SQLite vì mỗi service chỉ cần một file DB, có thể seed/reset ngay trên máy demo mà không cài DB server hay Docker. Điều này giữ yêu cầu “mỗi service một CSDL” và làm việc chạy lại thuận tiện. SQLite cũng được tài liệu chính thức đề cập cho [demo và giáo dục](https://www.sqlite.org/whentouse.html).

PostgreSQL/MySQL là phương án phù hợp nếu cần khảo sát DB server, mạng tới DB hoặc ghi đồng thời. Lab này chủ yếu đọc dữ liệu và đo API composition, nên nhóm ưu tiên setup local. Nhóm dùng SQL thuần thay ORM để nhìn rõ một SELECT tương ứng một DB query và bảo đảm batch thật sự chạy một SQL IN.

better-sqlite3 được dùng thống nhất với stack đã có, còn schema STRICT hỗ trợ kiểm soát kiểu dữ liệu. Đánh đổi là driver native cần cài phù hợp với runtime, truy vấn đồng bộ có thể chiếm event loop, và phép đo local không mô phỏng PostgreSQL hay môi trường nhiều writer. Nhóm không suy luận hiệu năng DB production từ kết quả này.

### 3.3 HTML/CSS/JavaScript và SVG cho UI

Nhóm chọn giao diện thuần để luồng fetch, thứ tự gọi, trạng thái lỗi và Performance marks dễ đọc trực tiếp. Cùng một hàm render được dùng cho cả ba phương pháp; khác biệt nằm ở cách lấy và normalize dữ liệu. Biểu đồ SVG có nhãn, thang đo, màu theo biến thể và khoảng min–max, không cần CDN khi demo.

React/Vue hoặc thư viện chart chuyên dụng có lợi cho UI lớn. Trong lab này, chúng sẽ thêm lớp công cụ/build và abstraction mà nhóm chưa cần. Đánh đổi: nhóm tự xử lý layout, accessibility và tương tác biểu đồ; thiết kế hiện tại phù hợp báo cáo nhỏ, không phải thư viện chart tổng quát.

### 3.4 Documentation bằng README, contract và GraphQL SDL

Documentation của Block 2 nằm trong README, bảng endpoint, query mẫu và SDL GraphQL. Demo có UI trực tiếp để chạy REST/BFF/GraphQL và xem kết quả. Schema GraphQL là contract thực thi cho query và selection set; REST dùng validation trong handler theo contract đã mô tả.

Nhóm chưa bổ sung Swagger UI/OpenAPI cho Block 2. Swagger là lựa chọn hữu ích cho việc mô tả và thử REST API, nhưng trọng tâm của bài này là so sánh composition, query selection, N+1 và evidence; nhóm ưu tiên UI dùng chung thay vì duy trì thêm bộ spec/UI cho từng REST service. Block 1 có Swagger/OpenAPI, nhưng đó không phải chức năng đã triển khai trong module này.

Đánh đổi: REST contract ở Block 2 chưa được kiểm tra từ một nguồn OpenAPI duy nhất và chưa có SDK sinh từ spec. Nếu phát triển thành hệ thống cho nhiều nhóm/client, nhóm sẽ bổ sung OpenAPI và kiểm tra response contract tự động. GraphiQL/GraphQL Playground cũng có thể bổ sung để thử query tự do; UI hiện tại tập trung hai query web/mobile và thao tác naive/batched phục vụ demo.

## 4. Lựa chọn schema và dữ liệu mẫu

| Bảng | Các trường |
|---|---|
| users | id, name |
| orders | id, user_id, product_id, quantity, total_cents, status, created_at |
| products | id, name, price_cents, thumbnail_url |

Nhóm chọn **mỗi đơn một product** để giảm độ phức tạp join/DTO và tập trung vào composition. Đây là quyết định đơn giản hóa, không phải yêu cầu của đề. Hiệu quả vẫn quan sát được vì product lặp giữa các đơn: small gồm P1/P2/P1/P3/P2; large gồm 100 đơn lặp năm product P1–P5.

Mô hình nhiều product/đơn với order_items sát nghiệp vụ bán hàng hơn. Khi mở rộng, nhóm sẽ chuyển quantity và tổng tiền dòng sang order_items, và số call baseline sẽ tăng theo số item. Phạm vi hiện tại đủ chứng minh call lặp và batching, nhưng không đại diện toàn bộ nghiệp vụ đơn hàng.

unit_price_cents và description được bỏ theo quyết định phạm vi. total_cents lưu giá trị tại thời điểm tạo đơn; giá hiện tại của Product không dùng tính lại tổng đơn. ID, thời điểm, giá và thứ tự seed cố định để so sánh lại được. Thumbnail là SVG local; _cents là đơn vị tiền tệ giả định, không phải giá trị VND thực tế.

## 5. Lựa chọn composition và tối ưu

### 5.1 Baseline tuần tự để quan sát chi phí từ browser

Browser gọi User, rồi Order, rồi Product theo từng đơn, kể cả product trùng. Với N đơn, baseline thực hiện N+2 API request. Nhóm giữ cách này đúng bối cảnh đề để thấy rõ waterfall và chi phí chờ nối tiếp.

REST vẫn có thể gọi song song, dedup hoặc batch. Vì vậy baseline này không được dùng để kết luận mọi REST implementation đều kém BFF/GraphQL. Nó là mốc so sánh cho luồng browser tuần tự đã chọn.

### 5.2 BFF theo từng client, kết hợp parallel + dedup + batch

BFF có endpoint web và mobile riêng. User/Order được gọi song song; sau khi có đơn, BFF dùng Set lấy productID duy nhất, gọi Product batch một lần rồi dùng Map ghép lại đúng thứ tự. Mobile trả DTO gọn, web trả đầy đủ dữ liệu đã chốt.

Dedup loại yêu cầu lấy product trùng, không loại đơn. Batch gom nhiều ID vào một HTTP call. Product Service chạy một SQL IN cho batch, thay vì lặp SELECT. Nếu chỉ gom endpoint ở browser nhưng BFF vẫn gọi Product từng đơn, N+1 nội bộ vẫn tồn tại.

Nhóm không thêm Redis hay cache xuyên request: một call/SQL Product phải đến từ batching trong request, không phải kết quả cache của lượt trước. BFF cũng không đọc thẳng ba DB hoặc dùng join xuyên DB, vì như vậy sẽ bỏ qua ranh giới service mà bài tập cần khảo sát.

### 5.3 GraphQL.js và DataLoader theo operation

Nhóm dùng GraphQL.js để schema, query selection, resolver và lỗi GraphQL thể hiện rõ. Nhóm không đưa thêm một framework GraphQL server lớn vì Express và hàm graphql đã đáp ứng các operation cần demo. Naive và batched dùng cùng endpoint/schema; mode được truyền bằng biến query và chọn trên UI.

Naive gọi Product trong resolver của từng đơn. Các resolver có thể chạy song song, nhưng với 100 đơn vẫn có 100 call và SQL Product. Batched dùng DataLoader tạo mới cho mỗi operation: các load cùng đợt được gom, key lặp dùng lại trong operation, kết quả batch được map về đúng key. Cách dùng này phù hợp [hướng dẫn DataLoader](https://github.com/graphql/dataloader).

Nhóm không tạo loader singleton để tránh cache tồn tại giữa người dùng/lượt chạy. Batched vẫn phải đọc Product lại ở operation kế tiếp; test kiểm tra điều đó. DataLoader không tự làm cho DB chạy một SQL: batch function vẫn cần gọi API batch đã thực hiện một SQL IN.

### 5.4 Web/mobile dùng cùng view model để đối chiếu

GraphQL response được normalize về cùng shape hiển thị với baseline/BFF. Web query lấy đủ trường đơn/product; mobile query lấy ID, trạng thái và tên/thumbnail product, cùng user{id} để kiểm tra User và hiển thị lỗi User khi cần.

Payload được đo **trước normalize**, tức body HTTP thật browser nhận. Vì vậy BFF DTO và GraphQL envelope/nested fields có thể có byte khác nhau dù UI hiển thị giống nhau. Nhóm không làm phẳng response GraphQL để giả lập một lợi thế payload.

## 6. Vì sao trả dữ liệu một phần khi lỗi?

Nhóm chọn policy partial để người dùng vẫn xem được đơn nếu phần tên/ảnh product chưa tải được. Phần lỗi được đặt null và có thông báo ngay tại vùng tương ứng. Nhóm không tạo tên/giá giả và không giữ kết quả cũ như dữ liệu của lượt mới.

| Sự cố | Dữ liệu còn giữ | Cách biểu diễn |
|---|---|---|
| User lỗi | Đơn và Product nếu lấy được | user=null, thông báo vùng User |
| Order lỗi | User nếu lấy được | orders=null, thông báo vùng danh sách |
| Product thiếu/lỗi | Các trường Order và Product còn lấy được | product=null, thông báo tại các card liên quan |
| Không có đơn thật sự | User | orders=[], trạng thái chưa có đơn |

Fail-fast sẽ đơn giản hơn cho client, nhưng một lỗi Product sẽ làm mất cả dashboard dù Order vẫn khả dụng. Partial phù hợp mục tiêu demo này; đổi lại nhóm phải duy trì scope/resource_id/order_ids và phân biệt danh sách rỗng với tải lỗi.

BFF dùng Promise.allSettled cho User/Order và HTTP200 với errors khi có kết quả một phần. GraphQL dùng User/Order làm root độc lập, Product nullable, data/errors kèm path/extensions. Tính nullable và vị trí lỗi quyết định phạm vi dữ liệu bị ảnh hưởng; tham khảo [GraphQL.js Errors](https://www.graphql-js.org/docs/graphql-errors/).

Timeout mỗi call upstream là 1.000 ms, không retry để số call phản ánh đúng chiến lược. Browser cho GraphQL operation tối đa 10 giây để nhận kết quả partial sau upstream timeout. Nhóm thử delay300ms, delay1500ms, lỗi500 và thiếuP1. Retry/circuit breaker có thể bổ sung cho production nhưng sẽ làm thay đổi phép đo của lab.

## 7. Vì sao Pino, JSONL và run_id; chưa dùng ELK?

Nhóm chọn Pino để tạo log JSON có cấu trúc trong cùng hệ sinh thái Node.js. JSONL giúp script lọc và tổng hợp theo từng lượt mà không phải parse câu log tự do; Pino hỗ trợ [log dạng JSON](https://github.com/pinojs/pino).

Mỗi lượt có run_id truyền từ browser tới app và xuống REST. Mỗi HTTP request có request_id; call có target và thời điểm; SQL được ghi ngay tại wrapper thực thi. Bốn loại event chính là request_start, request, service_call và db_query. Nhóm đếm ngay khi service nhận request để không bỏ sót request mà client đã abort.

console.log có thể dùng cho demo rất nhỏ, nhưng nhóm cần một format ổn định và metadata để đối chiếu. Winston cũng có thể đáp ứng log có cấu trúc; nhóm chọn Pino để thống nhất với code đã có, không benchmark hai logger để xếp hạng tốc độ.

ELK là lớp thu thập/tìm kiếm/phân tích log rộng hơn một thư viện logger. Trong bài tập local, thêm một hệ thống lưu trữ và giao diện phân tích log riêng làm tăng công việc setup mà JSONL và dashboard hiện tại đã đáp ứng. Nhóm không coi Pino là thay thế toàn bộ ELK; nếu hệ thống chạy nhiều máy và cần retention/search tập trung, log JSON có thể được đưa vào pipeline đó.

## 8. Vì sao Playwright và dashboard; chưa dùng Prometheus/Grafana?

Nhóm cần đo một **lần tải màn hình**, gồm request browser, body nhận, DOM, thumbnail và mốc render xong. Playwright chạy Chromium thật, cung cấp network events/HAR để chạy lại và đối chiếu; tài liệu [Playwright Network](https://playwright.dev/docs/network) mô tả các khả năng này. DevTools phù hợp quan sát thủ công, còn Playwright hỗ trợ nhiều lượt có điều kiện nhất quán.

Nhóm không dùng chỉ curl, Postman hay k6 thay cho phép đo màn hình, vì thời gian API trả về không bao gồm render/thumbnail của browser. Những công cụ đó có thể dùng kiểm tra endpoint hoặc tải đồng thời trong bài toán khác.

Prometheus/Grafana phù hợp khi cần metrics theo thời gian và giám sát dài hạn. Trong lab, các lượt ngắn có restart để đo cold; nhóm ưu tiên JSONL theo run_id, bảng mẫu và biểu đồ trên localhost. Chúng cho phép giải thích một lượt cụ thể và kiểm tra từng SQL/call. Đây là lựa chọn phạm vi, không phải nhận định công cụ giám sát đó không hữu ích.

UI có hai loại số đo được ghi rõ: so sánh nhanh một lượt mỗi biến thể trên browser hiện tại, và dashboard từ bộ Playwright5 lượt/cell. Nhóm không gọi số đo nhanh là median của bộ đo chuẩn.

## 9. Phương pháp đo và kiểm soát sai lệch

| Chỉ số | Định nghĩa |
|---|---|
| Browser API | Request dữ liệu từ browser; loại settings/metrics, HTML/JS/CSS/ảnh |
| Call nội bộ | Call HTTP ra từ app tới REST; baseline không có lớp app này |
| Request từng service | Request User/Order/Product nhận, gồm call từ browser hoặc app |
| DB query | SQL thực thi tại wrapper; không suy ra từ số endpoint |
| Màn hình hoàn tất | API đầu → dữ liệu/lỗi vào DOM → ảnh khả dụng decode xong → hai animation frames |
| Payload | Tổng byte body JSON UTF-8 browser thật sự nhận, không nén/header; upstream/static riêng |

Healthy gồm 4 biến thể × 2 client × 2 dataset × 2 mode × 5 = **160 mẫu**. Failure gồm 4 kịch bản × 4 biến thể × 2 client × 5, small/warm = **160 mẫu**. Mỗi nhóm báo median và khoảng min–max; complete/partial/failed không bị trộn.

Cold là restart bốn process trước từng mẫu; readiness không query dữ liệu nghiệp vụ. Warm chạy một lượt không tính rồi5 mẫu. Mỗi mẫu browser context mới; API no-store; viewport1100×800; không throttling hay compression; chạy tuần tự. Thời gian đổi cấu hình/seed không nằm trong thời gian màn hình.

Khi timeout, upstream vẫn có thể thực thi SQL sau client abort. Collector chờ thêm1.700ms ngoài duration để thu việc này. Collector có mốc request-event dự phòng khi timing abort bị thiếu; dashboard có thể khôi phục timing của artifact cũ từ HAR mà giữ nguyên dữ liệu gốc.

Môi trường đo: Node22.17.0, macOS/arm64, Apple M1 Pro, Chromium156.0.8078.4. Các thư viện đang cài: Express5.2.1, better-sqlite3 11.10.0, GraphQL.js16.14.2, DataLoader2.2.3, Pino10.4.0, Playwright1.64.0, TypeScript5.9.3. Lockfile giữ các phiên bản để chạy lại.

## 10. Kết quả thực nghiệm và cách giải thích

### 10.1 Dataset100 đơn, chế độ warm

Mỗi dòng dưới đây có 5 mẫu. Thời gian ghi **median [min–max]**, đơn vịms. SQL tổng gồm User + Order + Product. Call Product trong các nhóm healthy bằng SQL Product vì mỗi endpoint dữ liệu thực thi một SELECT.

| Client / biến thể | Thời gian ms [min–max] | Browser API | SQL Product | SQL tổng | JSON bytes |
|---|---:|---:|---:|---:|---:|
| Web / Baseline | 118,7 [118,5–168,2] | 102 | 100 | 102 | 22.389 |
| Web / BFF | 35,9 [35,3–52,0] | 1 | 1 | 3 | 23.509 |
| Web / GraphQL naive | 52,3 [51,7–69,5] | 1 | 100 | 102 | 23.506 |
| Web / GraphQL batched | 52,0 [35,1–52,3] | 1 | 1 | 3 | 23.506 |
| Mobile / Baseline | 103,7 [101,9–119,1] | 102 | 100 | 102 | 22.389 |
| Mobile / BFF | 35,2 [34,5–35,8] | 1 | 1 | 3 | 9.283 |
| Mobile / GraphQL naive | 52,2 [51,6–52,7] | 1 | 100 | 102 | 9.699 |
| Mobile / GraphQL batched | 35,8 [34,8–36,5] | 1 | 1 | 3 | 9.699 |

<!-- report-charts -->

**Composition giảm request từ browser, nhưng chưa đủ giảm công việc nội bộ.** GraphQL naive có một operation nhưng vẫn100 SQL Product. BFF batch và GraphQL batched giảm về1 SQL Product, không tăng khi số đơn tăng từ5 lên100.

**Batching không được chứng minh luôn tạo thời gian nhỏ nhất.** Ở Web/warm, median GraphQL naive52,3ms và batched52,0ms gần nhau, dù SQL khác nhiều. Khoảng batched35,1–52,3ms cũng cho thấy độ biến thiên. Nhóm chỉ kết luận chắc về số call/SQL trong tập chạy này; không khẳng định thứ hạng latency tổng quát. Duration còn chờ hai animation frame và chịu ảnh hưởng lịch render/JIT; nhóm chưa profiling để tách tỷ trọng từng thành phần, nên không quy toàn bộ chênh lệch cho framework.

**Payload web không giảm.** Web BFF/GraphQL lớn hơn baseline ở nhóm này do shape ghép/nested envelope; nhóm giữ số đo này. Mobile BFF giảm từ22.389 xuống9.283 byte, khoảng58,5%; GraphQL giảm xuống9.699 byte, khoảng56,7%, nhờ lựa chọn trường. Naive/batched trả cùng selection set nên payload healthy GraphQL bằng nhau; tối ưu batching nằm phía server.

### 10.2 Product chậm hoặc timeout

| Small / web, warm | Baseline | BFF | GraphQL naive | GraphQL batched |
|---|---:|---:|---:|---:|
| Delay300ms, medianms | 1.585,4 | 352,2 | 367,4 | 350,4 |
| Timeout1500ms, medianms | 5.035,1 | 1.035,5 | 1.036,1 | 1.036,5 |

Các giá trị được làm tròn một chữ số sau dấu phẩy. Delay300ms vẫn complete; timeout chuyển partial và giữ đơn. Baseline chờ năm Product call nối tiếp. GraphQL naive chờ các call song song, nên thời gian timeout gần BFF/batched nhưng vẫn có nhiều call/SQL hơn. Đây là ví dụ cho thấy phải đọc đồng thời thời gian và công việc nội bộ.

Lỗi500 xảy ra trước SELECT Product nên SQL Product bằng0; thiếuP1 chỉ làm null các đơn liên quan. Cả bốn biến thể cho view model và lỗi tương ứng khớp. Các số đo lỗi/thiếu còn lại nằm trong bảng mẫu đầy đủ, không thay bằng số dự đoán.

## 11. Kiểm chứng, evidence và cách chạy lại

Nhóm đã kiểm tra typecheck và bộ test báo **22 tests pass, 0 fail**. Các case gồm equality web/mobile, N+1/batch với5/100 đơn, loader không cache xuyên operation, Product thiếu/lỗi/timeout, User/Order lỗi độc lập, invalid query, và đổi mode/dataset/lỗi bằng UI. Suite GraphQL/controller8 tests được chạy lại sau khi thêm guard cấu hình trong lúc đo.

Hai bộ đo cuối có **320 HAR và320 view model**, mỗi bộ160 mẫu. equality.json ghi152 đối chiếu thành công mỗi bộ, tổng304. Số call/SQL được đối chiếu lại với JSONL; payload được đối chiếu với kích thước body trong HAR. Các assertion so sánh chạy thật, không dùng câu trả lời của agent làm evidence.

- [Healthy160 mẫu: CSV/JSON, HAR, log và summary](evidence/healthy-2026-10-08T04-02-09-887Z/report.html).
- [Failure160 mẫu: CSV/JSON, HAR, log và summary](evidence/failure-2026-10-08T04-06-11-022Z/report.html).
- [Log kiểm thử cuối: 22 pass, 0 fail](evidence/acceptance-test.txt).
- [Kết quả tóm tắt](RESULTS.md).
- [README chạy lại](README.md).

```bash
cd Block-2-W02
npm ci
npx playwright install chromium
npm run typecheck
npm test
npm run measure
npm run evidence:failure
npm run dev
```

Dừng demo trước test/đo để giải phóng cổng. Khi demo chạy, mở http://localhost:3000 và http://localhost:3000/measurements. Chọn naive/batched, dataset và lỗi bằng UI, không cần sửa code hoặc chạy lại lệnh đổi mode. Lệnh test/đo dùng runner tự quản lý process.

Các file evidence được gitignore để giữ repo source gọn; khi nộp phải đính kèm hai thư mục evidence cuối cùng. Báo cáo80 mẫu cũ và evidence của Block-2/ không được trộn vào kết quả tích hợp320 mẫu.

## 12. Giới hạn và hướng mở rộng

- Đây là localhost, dữ liệu giả nhỏ và browser headless; kết quả chưa đại diện mạng mobile, tải đồng thời hay production.
- Cold chỉ làm lạnh process, không xóa OS disk cache. Mỗi browser context mới giúp thống nhất điều kiện client, nhưng không chứng minh toàn bộ hệ thống cold.
- Năm mẫu là mức thực hành của đề; thứ tự đo cố định, chưa randomize hay kiểm tra ý nghĩa thống kê. Median/min–max không thay cho phân tích p95/p99 dưới tải.
- Baseline cố ý tuần tự; một REST client đã tối ưu có thể thu hẹp khoảng cách. Nhóm chưa đo baseline parallel/dedup như một biến thể riêng.
- Một product/đơn và driver SQLite đồng bộ làm bài toán gọn, nhưng hạn chế tính đại diện nghiệp vụ/DB production.
- BFF lấy Product đầy đủ ở upstream; DTO mobile chỉ giảm payload app→browser. GraphQL cũng không tự loại overfetch của REST upstream chỉ nhờ selection set.
- UI quick comparison là một lượt/biến thể, không có protocol cold/warm/context mới như bộ Playwright. Các con số của nó dùng giải thích tại demo, không thay evidence320 mẫu.

Hướng mở rộng gồm order_items nhiều product/đơn, baseline tối ưu, contract OpenAPI cho REST, test tải đồng thời và mạng có latency, timeout/circuit breaker theo policy sản phẩm, và log/metrics tập trung nếu triển khai nhiều máy. Các thay đổi này phải được đưa vào plan và đo lại trên cùng điều kiện trước khi kết luận.

## 13. Kết luận của nhóm

Kết quả cuối cho thấy lớp composition giúp browser lấy màn hình bằng một request. Tuy nhiên, hiệu quả phía server phụ thuộc cách lấy dữ liệu: GraphQL naive vẫn N+1, còn BFF batch và GraphQL DataLoader giảm call/SQL Product. DTO/query gọn giảm payload mobile; payload web và latency không được bảo đảm luôn giảm.

Nhóm chọn stack và công cụ vừa đủ để giải thích được các khác biệt đó bằng code, UI và evidence có thể chạy lại. Những đánh đổi về schema đơn giản, SQLite, documentation và logging đều được ghi rõ thay vì coi bản demo là thiết kế production hoàn chỉnh.
