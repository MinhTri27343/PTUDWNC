import {spawn,type ChildProcess} from 'node:child_process';
import net from 'node:net';
import fs from 'node:fs';
import path from 'node:path';
import {root,seed} from './seed.ts';
import {initialSettings,scenarios} from '../src/demo-control.ts';
export type Service='user'|'order'|'product'|'bff';
export const sleep=(ms:number)=>new Promise(resolve=>setTimeout(resolve,ms));
const ports:Record<Service,number>={bff:3000,user:3001,order:3002,product:3003};
export class Cluster {
 children=new Map<Service,ChildProcess>();events:any[]=[];
 constructor(public directory?:string){if(directory)fs.mkdirSync(directory,{recursive:true});}
 async free(service:Service){await new Promise<void>((resolve,reject)=>{
  const probe=net.createServer();probe.once('error',()=>reject(new Error(`Port ${ports[service]} is occupied; stop the existing demo/process first.`)));
  probe.listen(ports[service],'localhost',()=>probe.close(()=>resolve()));
 });}
 async startService(service:Service,environment:Record<string,string>={}){
  await this.free(service);
  const child=spawn(process.execPath,['--import','tsx',path.join(root,'src/server.ts'),service],{cwd:root,env:{...process.env,PRODUCT_DELAY_MS:'0',PRODUCT_FAIL:'false',PRODUCT_MISSING_ID:'',...environment},stdio:['ignore','pipe','pipe','ipc']});
  this.children.set(service,child);let remainder='';
  child.stdout!.on('data',chunk=>{
   remainder+=chunk.toString();const lines=remainder.split('\n');remainder=lines.pop()!;
   for(const line of lines){if(!line)continue;try{this.events.push(JSON.parse(line));}catch{console.error(line);}if(this.directory)fs.appendFileSync(path.join(this.directory,'logs.jsonl'),line+'\n');}
  });
  child.stderr!.on('data',chunk=>console.error(`[${service}] ${chunk}`));child.on('error',error=>console.error(error));
  const deadline=Date.now()+15000;
  while(Date.now()<deadline){
   if(child.exitCode!==null)throw new Error(`${service} exited during startup`);
   try{if((await fetch(`http://localhost:${ports[service]}/health`,{signal:AbortSignal.timeout(500)})).ok)return;}catch{}
   await sleep(80);
  }
  throw new Error(`${service} did not become ready`);
 }
 async start(environment:Record<string,string>={}){
  for(const service of Object.keys(ports) as Service[])await this.free(service);
  try{await Promise.all((['user','order','product','bff'] as Service[]).map(service=>this.startService(service,environment)));}catch(error){await this.stop();throw error;}
 }
 enableDemoControls(){
  const child=this.children.get('bff')!;let busy=false;let settings=initialSettings();
  child.on('message',async(message:any)=>{
   if(!['demo-settings','demo-metrics'].includes(message?.type))return;
   const reply=(result:any,error?:string)=>{if(child.connected)child.send({type:'demo-result',id:message.id,ok:!error,result,error});};
   if(message.type==='demo-metrics'){
    const events=this.events.filter(event=>event.run_id===message.payload.run_id);
    const incoming=events.filter(event=>event.event==='request_start'&&event.service!=='bff');
    const reads=events.filter(event=>event.event==='db_query');const calls=events.filter(event=>event.event==='service_call');
    const browserRequests=events.filter(event=>event.event==='request_start'&&(event.service==='bff'||!calls.length));
    const bodyResponses=events.filter(event=>event.event==='request'&&(event.service==='bff'||!calls.length));
    const result:any={browser_api_requests:browserRequests.length,service_calls:calls.length,db_queries:reads.length,api_bytes:bodyResponses.reduce((sum,event)=>sum+event.bytes,0),calls};
    for(const service of ['user','order','product']){result[`${service}_requests`]=incoming.filter(e=>e.service===service).length;result[`${service}_queries`]=reads.filter(e=>e.service===service).length;}
    reply(result);return;
   }
   if(busy){reply(null,'Đang đổi cấu hình.');return;}busy=true;
   const previous=settings;
   try{
    const {dataset,scenario}=message.payload;
    if(!['small','large'].includes(dataset)||!Object.hasOwn(scenarios,scenario))throw new Error('Cấu hình không hợp lệ.');
    await Promise.all((['user','order','product'] as Service[]).map(service=>this.stopService(service)));
    seed(dataset);
    await Promise.all((['user','order','product'] as Service[]).map(service=>this.startService(service,scenarios[scenario])));
    settings={dataset,scenario};reply(settings);
   }catch(error:any){
    try{await Promise.all((['user','order','product'] as Service[]).map(service=>this.stopService(service)));seed(previous.dataset);await Promise.all((['user','order','product'] as Service[]).map(service=>this.startService(service,scenarios[previous.scenario])));}catch{}
    reply(null,error.message);
   }finally{busy=false;}
  });
  if(child.connected)child.send({type:'demo-ready'});
 }
 async stopService(service:Service){
  const child=this.children.get(service);if(!child)return;
  if(child.exitCode===null&&child.signalCode===null)await new Promise<void>(resolve=>{
   const timer=setTimeout(()=>child.kill('SIGKILL'),3000);child.once('exit',()=>{clearTimeout(timer);resolve();});child.kill('SIGTERM');
  });this.children.delete(service);
 }
 async stop(){await Promise.all([...this.children.keys()].map(service=>this.stopService(service)));}
}
