import fs from 'node:fs';
import path from 'node:path';
import { Cluster } from './runner.ts';
import { root, seed } from './seed.ts';
if (!fs.existsSync(path.join(root,'data/order.db'))) seed('small');
const cluster = new Cluster();
let stopping = false;
for (const signal of ['SIGINT','SIGTERM'] as const) process.on(signal, async () => {
  if (stopping) return; stopping = true; await cluster.stop(); process.exit(0);
});
try {
  await cluster.start({ PRODUCT_DELAY_MS:process.env.PRODUCT_DELAY_MS || '0', PRODUCT_FAIL:process.env.PRODUCT_FAIL || 'false', PRODUCT_MISSING_ID:process.env.PRODUCT_MISSING_ID || '' });
  cluster.enableDemoControls();
  console.log('Demo: http://localhost:3000 — Ctrl+C để dừng cả bốn process.');
} catch (error) { console.error(error); await cluster.stop(); process.exitCode=1; }
