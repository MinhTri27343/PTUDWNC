import fs from 'node:fs';
import path from 'node:path';
function escape(value:any) { return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]!)); }
export function summarize(rows:any[]) {
  const groups = new Map<string,any[]>();
  for (const row of rows) {
    const key = [row.scenario,row.variant,row.client,row.dataset,row.mode,row.state].join('/');
    if (!groups.has(key)) groups.set(key,[]); groups.get(key)!.push(row);
  }
  const statistics = (values:number[]) => {
    const sorted = [...values].sort((a,b)=>a-b); const middle=Math.floor(sorted.length/2);
    return { median:sorted.length%2 ? sorted[middle] : (sorted[middle-1]+sorted[middle])/2, min:sorted[0], max:sorted[sorted.length-1] };
  };
  return [...groups].map(([group, samples]) => ({ group, count:samples.length,
    metrics:Object.fromEntries(['duration_ms','browser_api_requests','service_calls','db_queries','api_bytes','upstream_bytes','static_bytes'].map(metric=>[metric,statistics(samples.map(row=>row[metric]))])) }));
}
export function report(directory:string, rows:any[], environment:any) {
  const summary = summarize(rows);
  fs.writeFileSync(path.join(directory,'raw.json'),JSON.stringify({environment,rows},null,2));
  fs.writeFileSync(path.join(directory,'summary.json'),JSON.stringify(summary,null,2));
  const columns = ['run_id','scenario','variant','client','dataset','mode','iteration','state','duration_ms','browser_api_requests','service_calls','db_queries','api_bytes','upstream_bytes','static_requests','static_bytes','user_requests','order_requests','product_requests','user_queries','order_queries','product_queries'];
  fs.writeFileSync(path.join(directory,'raw.csv'),columns.join(',')+'\n'+rows.map(row=>columns.map(key=>JSON.stringify(row[key] ?? '')).join(',')).join('\n'));
  fs.writeFileSync(path.join(directory,'report.html'),`<!doctype html><html lang="vi"><meta charset="utf-8"><title>Baseline × BFF evidence</title><style>
  body{font:14px system-ui;color:#173332;background:#f2f5f1;margin:32px}h1{font-size:32px}table{border-collapse:collapse;width:100%;background:white;margin:20px 0}td,th{border:1px solid #dce5dc;padding:8px;text-align:left}th{background:#dcece2}details{background:white;border-radius:8px;padding:14px;margin:12px 0}a{color:#145e50}.track{position:relative;background:#eef3ee;height:22px;margin:3px 0}.bar{position:absolute;background:#36776b;height:15px;top:3px;min-width:2px}.marker{position:absolute;top:0;bottom:0;width:2px;background:#cf5d39}.legend{font-size:12px;color:#607371}pre{white-space:pre-wrap}svg{max-width:100%}</style>
  <h1>Baseline × BFF · kết quả chạy thật</h1><p>${rows.length} mẫu. Median [min–max]; các nhóm complete/partial/failed và cold/warm tách riêng. API bytes = body JSON UTF-8, không gồm headers; static riêng.</p><details><summary>Môi trường & giới hạn</summary><pre>${escape(JSON.stringify(environment,null,2))}</pre><p>Localhost, mobile mô phỏng browser; restart không xóa cache hệ điều hành. Không cache liên request, không nén. Giảm call/SQL Product có cả đóng góp batch/dedup, ngoài lợi ích composition của BFF.</p></details>
  <p><a href="raw.csv">Raw CSV</a> · <a href="raw.json">Raw JSON</a> · <a href="summary.json">Summary JSON</a> · <a href="logs.jsonl">Service logs</a> · <a href="equality.json">Đối chiếu model</a></p>
  <table><thead><tr><th>Nhóm scenario/variant/client/dataset/mode/state</th><th>n</th><th>ms</th><th>Browser API</th><th>Internal call</th><th>SQL</th><th>API bytes</th></tr></thead><tbody>${summary.map(group=>`<tr><td>${escape(group.group)}</td><td>${group.count}</td>${['duration_ms','browser_api_requests','service_calls','db_queries','api_bytes'].map(metric=>{const s=group.metrics[metric];return `<td>${s.median.toFixed(1)} [${s.min.toFixed(1)}–${s.max.toFixed(1)}]</td>`;}).join('')}</tr>`).join('')}</tbody></table>
  <h2>Biểu đồ median theo nhóm</h2><p class="legend">Mỗi cột chỉ so sánh trong cùng chỉ số. Xem nhãn nhóm để đối chiếu đúng scenario/client/dataset/mode/state.</p>${['duration_ms','browser_api_requests','service_calls','db_queries','api_bytes'].map(metric=>{const max=Math.max(1,...summary.map(g=>g.metrics[metric].median));return `<details open><summary>${metric}</summary>${summary.map(g=>`<div>${escape(g.group)} · ${g.metrics[metric].median.toFixed(1)}</div><div class="track"><div class="bar" style="width:${100*g.metrics[metric].median/max}%"></div></div>`).join('')}</details>`;}).join('')}
  <h2>Từng lượt: waterfall & call graph</h2>${rows.map(row=>{
    const min=Math.min(0,...row.requests.map((r:any)=>r.start)); const max=Math.max(row.duration_ms,...row.requests.map((r:any)=>r.end),1); const x=(n:number)=>Math.max(0,Math.min(100,100*(n-min)/(max-min)));
    return `<details><summary>${escape(row.run_id)} · ${row.variant}/${row.client}/${row.dataset}/${row.mode} · ${row.state} · ${row.duration_ms.toFixed(1)} ms</summary><p><a href="${escape(row.run_id)}.har">HAR</a> · ${row.browser_api_requests} browser API; service requests U/O/P=${row.user_requests}/${row.order_requests}/${row.product_requests}; SQL=${row.user_queries}/${row.order_queries}/${row.product_queries}</p><p class="legend">Vạch cam: màn hình hoàn tất. Thời gian tương đối so với API đầu tiên; trục ${min.toFixed(1)} đến ${max.toFixed(1)} ms.</p>${row.requests.map((r:any)=>`<div>${escape(r.method+' '+r.url)} · ${r.status} · ${r.bytes} bytes</div><div class="track"><span class="bar" style="left:${x(r.start)}%;width:${Math.max(.1,x(r.end)-x(r.start))}%"></span><span class="marker" style="left:${x(row.duration_ms)}%"></span></div>`).join('')}<h3>Call graph nội bộ</h3>${row.variant!=='baseline' ? `<svg width="760" height="${Math.max(100,row.calls.length*70)}" viewBox="0 0 760 ${Math.max(100,row.calls.length*70)}"><rect x="5" y="20" width="110" height="45" rx="6" fill="#dcece2"/><text x="25" y="48">Browser → ${row.variant==='bff'?'BFF':'GraphQL'}</text>${row.calls.map((call:any,i:number)=>`<path d="M115 43 L390 ${i*70+43}" stroke="#36776b"/><rect x="390" y="${i*70+20}" width="355" height="45" rx="6" fill="#dcece2"/><text x="400" y="${i*70+39}">${escape(call.target)} · ${escape(call.route)}</text><text x="400" y="${i*70+57}">${call.end-call.start} ms · ${call.status || call.code} · ${call.bytes} bytes</text>`).join('')}</svg>` : '<p>Browser gọi trực tiếp service tuần tự; không có call giữa service.</p>'}<details><summary>Log SQL/call của lượt</summary><pre>${escape(JSON.stringify(row.events,null,2))}</pre></details></details>`;
  }).join('')}</html>`);
}
