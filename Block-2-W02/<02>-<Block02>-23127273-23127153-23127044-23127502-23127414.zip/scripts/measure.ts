import { chromium, type Browser } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { Cluster, sleep } from './runner.ts';
import { root, seed } from './seed.ts';
import { report } from './report.ts';
const failure = process.argv.includes('--failure');
const quick = process.argv.includes('--quick');
const count = quick ? 1 : 5;
const directory = path.join(root,'evidence',`${failure?'failure':'healthy'}-${new Date().toISOString().replace(/[:.]/g,'-')}`);
fs.mkdirSync(directory,{recursive:true});
const cluster = new Cluster(directory);
const rows:any[]=[];
const models = new Map<string,any>();
const equality:any[]=[];
let browser:Browser;
function isApi(url:string) { return /^\/(users|orders|products|bff|graphql)(\/|$)/.test(new URL(url).pathname); }
async function sample(meta:any, save:boolean) {
  const runId = `${meta.variant}-${meta.client}-${meta.dataset}-${meta.mode}-${randomUUID()}`;
  const context = await browser.newContext({ viewport:{width:1100,height:800}, recordHar:save?{path:path.join(directory,`${runId}.har`),mode:'full'}:undefined });
  try {
    const page = await context.newPage();
    const requests:any[]=[];
    const pending:Promise<void>[]=[];
    const requestStarts=new WeakMap<object,number>();
    page.on('request',request=>requestStarts.set(request,Date.now()));
    page.on('requestfinished', request => {
      pending.push((async()=>{
        const response=await request.response();
        const timing=request.timing();
        const body=await response?.body();
        requests.push({url:request.url(),method:request.method(),status:response?.status() || 0,bytes:body?.length || 0,
          absoluteStart:timing.startTime,absoluteEnd:timing.startTime+Math.max(timing.responseEnd,0),api:isApi(request.url())});
      })());
    });
    page.on('requestfailed', request => {
      const timing=request.timing();
      requests.push({url:request.url(),method:request.method(),status:0,bytes:0,absoluteStart:timing.startTime>0?timing.startTime:requestStarts.get(request)!,absoluteEnd:Date.now(),api:isApi(request.url()),error:request.failure()?.errorText,timing_source:timing.startTime>0?'playwright':'request-event'});
    });
    await page.goto(`http://localhost:3000/?autorun=1&variant=${meta.variant.startsWith('graphql')?'graphql':meta.variant}&graphql_mode=${meta.variant.endsWith('naive')?'naive':'batched'}&client=${meta.client}&run_id=${runId}`,{waitUntil:'domcontentloaded'});
    await page.waitForFunction(()=>['ready','failed'].includes(document.querySelector('#screen')!.getAttribute('data-state')!),{},{timeout:30000});
    const result:any = await page.evaluate(()=>({ ...(window as any).demoResult, timeOrigin:performance.timeOrigin }));
    if (!result.model) throw new Error(`Application failed: ${JSON.stringify(result)}`);
    await Promise.all(pending);
    await sleep(meta.scenario==='timeout' ? 1700 : 30);
    const events=cluster.events.filter(event=>event.run_id===runId);
    const origin=result.timeOrigin+result.start;
    const calls=events.filter(event=>event.event==='service_call');
    const reads=events.filter(event=>event.event==='db_query');
    const incoming=events.filter(event=>event.event==='request_start' && event.service!=='bff');
    const row:any={...meta,run_id:runId,state:result.state,duration_ms:result.duration,
      browser_api_requests:requests.filter(r=>r.api).length,service_calls:calls.length,db_queries:reads.length,
      api_bytes:requests.filter(r=>r.api).reduce((sum,r)=>sum+r.bytes,0),upstream_bytes:calls.reduce((sum,r)=>sum+r.bytes,0),
      static_requests:requests.filter(r=>!r.api).length,static_bytes:requests.filter(r=>!r.api).reduce((sum,r)=>sum+r.bytes,0),
      requests:requests.map(r=>({...r,start:r.absoluteStart-origin,end:r.absoluteEnd-origin})),calls,events};
    for (const service of ['user','order','product']) {
      row[`${service}_requests`]=incoming.filter(event=>event.service===service).length;
      row[`${service}_queries`]=reads.filter(event=>event.service===service).length;
    }
    if (meta.scenario==='healthy') {
      const n=meta.dataset==='small'?5:100;
      assert.equal(row.state,'complete');
      assert.equal(row.browser_api_requests,meta.variant==='baseline'?n+2:1);
      const batched=meta.variant==='bff'||meta.variant==='graphql-batched';
      assert.equal(row.product_requests,batched?1:n);
      assert.equal(row.product_queries,batched?1:n);
      assert.equal(row.db_queries,batched?3:n+2);
      assert.equal(row.service_calls,meta.variant==='baseline'?0:batched?3:n+2);
    } else assert.equal(row.state,meta.scenario==='slow'?'complete':'partial');
    const key=[meta.scenario,meta.client,meta.dataset,meta.mode].join('/');
    if (!save) return;
    const previous=models.get(key);
    if (previous) { assert.deepEqual(result.model,previous.model); equality.push({run_id:runId,compared_to:previous.run_id,equal:true}); }
    models.set(key,{model:result.model,run_id:runId});
    fs.writeFileSync(path.join(directory,`${runId}.model.json`),JSON.stringify(result.model,null,2));
    rows.push(row);
    console.log(`${rows.length}: ${meta.scenario}/${meta.variant}/${meta.client}/${meta.dataset}/${meta.mode} ${row.duration_ms.toFixed(1)}ms · browser=${row.browser_api_requests} · SQL=${row.db_queries} · ${row.state}`);
  } finally { await context.close(); }
}
const scenarios:Record<string,Record<string,string>> = failure ? {
  slow:{PRODUCT_DELAY_MS:'300'},timeout:{PRODUCT_DELAY_MS:'1500'},error:{PRODUCT_FAIL:'true'},missing:{PRODUCT_MISSING_ID:'P1'}
} : {healthy:{}};
const environment:any={node:process.version,platform:os.platform(),arch:os.arch(),cpu:os.cpus()[0]?.model,viewport:{width:1100,height:800},count,quick,protocols:['baseline','bff','graphql-naive','graphql-batched'],network:'localhost, no throttling',seed:'small P1/P2/P1/P3/P2; large P1-P5 repeated',compression:false,created_at:new Date().toISOString()};
for (const signal of ['SIGINT','SIGTERM'] as const) process.on(signal,async()=>{await cluster.stop();await browser?.close();process.exit(130);});
try {
  browser=await chromium.launch(); environment.chromium=browser.version();
  for (const [scenario,config] of Object.entries(scenarios)) for (const dataset of (failure||quick?['small']:['small','large'])) {
    for (const mode of (failure?['warm']:['cold','warm'])) for (const variant of ['baseline','bff','graphql-naive','graphql-batched']) for (const client of ['web','mobile']) {
      await cluster.stop(); seed(dataset);
      if (mode==='warm') {
        await cluster.start(config);
        await sample({scenario,dataset,mode,variant,client,iteration:0},false);
      }
      for (let iteration=1;iteration<=count;iteration++) {
        if (mode==='cold') { await cluster.stop(); await cluster.start(config); }
        await sample({scenario,dataset,mode,variant,client,iteration},true);
      }
    }
  }
  assert.equal(rows.length, quick ? (failure?32:16) : 160);
  fs.writeFileSync(path.join(directory,'equality.json'),JSON.stringify(equality,null,2));
  report(directory,rows,environment);
  console.log(`Report: ${path.join(directory,'report.html')}`);
} finally {
  await cluster.stop(); await browser!?.close();
  if (rows.length && !fs.existsSync(path.join(directory,'report.html'))) {
    fs.writeFileSync(path.join(directory,'equality.json'),JSON.stringify(equality,null,2));
    report(directory,rows,{...environment,incomplete:true});
  }
}
