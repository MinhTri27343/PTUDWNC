import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
export const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const prices = [120000, 250000, 80000, 450000, 160000];
export function seed(dataset = 'small') {
  if (!['small', 'large'].includes(dataset)) throw new Error('dataset must be small or large');
  const directory = path.join(root, 'data');
  fs.mkdirSync(directory, { recursive: true });
  for (const service of ['user', 'order', 'product']) {
    for (const suffix of ['', '-wal', '-shm']) fs.rmSync(path.join(directory, `${service}.db${suffix}`), { force: true });
    const db = new Database(path.join(directory, `${service}.db`));
    if (service === 'user') {
      db.exec('CREATE TABLE users (id TEXT PRIMARY KEY, name TEXT NOT NULL) STRICT');
      db.prepare('INSERT INTO users VALUES (?,?)').run('U1', 'Nguyễn Minh An');
      db.prepare('INSERT INTO users VALUES (?,?)').run('U2', 'Người dùng chưa có đơn');
    } else if (service === 'product') {
      db.exec('CREATE TABLE products (id TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL CHECK(price_cents>=0), thumbnail_url TEXT NOT NULL) STRICT');
      const insert = db.prepare('INSERT INTO products VALUES (?,?,?,?)');
      ['Bàn phím', 'Tai nghe', 'Chuột', 'Màn hình', 'Loa'].forEach((name, i) =>
        insert.run(`P${i + 1}`, name, prices[i], `/images/P${i + 1}.svg`));
    } else {
      db.exec('CREATE TABLE orders (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, product_id TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity>0), total_cents INTEGER NOT NULL CHECK(total_cents>=0), status TEXT NOT NULL, created_at TEXT NOT NULL) STRICT; CREATE INDEX orders_user ON orders(user_id)');
      const insert = db.prepare('INSERT INTO orders VALUES (?,?,?,?,?,?,?)');
      db.transaction(() => {
        for (let i = 0; i < (dataset === 'small' ? 5 : 100); i++) {
          const quantity = i % 3 + 1;
          const productIndex = dataset === 'small' ? [0, 1, 0, 2, 1][i] : i % 5;
          insert.run(`O${String(i + 1).padStart(3, '0')}`, 'U1', `P${productIndex + 1}`, quantity,
            prices[productIndex] * quantity, ['pending', 'shipping', 'delivered'][i % 3],
            new Date(Date.UTC(2026, 0, 1, 0, i)).toISOString());
        }
      })();
    }
    db.close();
  }
  // Cross-service references cannot be enforced by a foreign key.
  const users = new Database(path.join(directory, 'user.db'));
  const products = new Database(path.join(directory, 'product.db'));
  const orders = new Database(path.join(directory, 'order.db'));
  for (const row of orders.prepare('SELECT user_id,product_id FROM orders').all() as { user_id:string; product_id:string }[]) {
    if (!users.prepare('SELECT id FROM users WHERE id=?').get(row.user_id) || !products.prepare('SELECT id FROM products WHERE id=?').get(row.product_id)) throw new Error('Invalid seed reference');
  }
  users.close(); products.close(); orders.close();
  fs.writeFileSync(path.join(directory,'dataset.json'),JSON.stringify({dataset}));
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  seed(process.argv.includes('--dataset') ? process.argv[process.argv.indexOf('--dataset') + 1] : 'small');
  console.log('SQLite databases seeded.');
}
