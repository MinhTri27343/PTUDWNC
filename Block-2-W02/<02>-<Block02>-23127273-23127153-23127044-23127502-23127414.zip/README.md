# Baseline · BFF · GraphQL — một demo chung

Block 2 được tích hợp trong **Block-2-W02**: cùng User/Order/Product, cùng ba SQLite, cùng seed, giao diện, policy lỗi và cách đo. GraphQL được chuyển từ nhánh `feat/graphql` sang contract của module này; `Block-2/` giữ bản gốc tham khảo.

## Chạy và trình bày bằng UI

Yêu cầu Node.js22+, npm:

```bash
npm ci
npm run dev
```

Mở **http://localhost:3000**. Runner tự seed small nếu chưa có DB. Chọn ngay trên trang:

- **Luồng:** Baseline / BFF / GraphQL.
- **GraphQL:** Naive (N+1) / Batched (DataLoader), áp dụng theo từng request; không đổi biến môi trường hay restart.
- **Dữ liệu:** 5 / 100 đơn.
- **Product:** bình thường / chậm300ms / timeout1500ms / lỗi500 / thiếuP1.
- **Client:** web / mobile; userU1 có đơn, U2 chưa có đơn.

Bấm **Tải màn hình** để áp dụng cấu hình và lấy dữ liệu. Đổi dataset/scenario sẽ đóng ba data service, seed lại dataset giả và khởi động chúng; app3000 giữ kết nối trả kết quả. Phần đổi cấu hình được thực hiện trước mốc thời gian màn hình. Ctrl+C dừng cả cluster.

Bấm **So sánh cả 3 phương pháp**: browser chạy Baseline → BFF → GraphQL naive → GraphQL batched, hiển thị thời gian, browser API, call Product, SQL, payload và trạng thái. Đây là **một lượt mỗi biến thể**, dùng để demo nhanh, không phải median hay bằng chứng cold/warm5 mẫu.

Bấm **Xem số đo & biểu đồ** hoặc mở **http://localhost:3000/measurements**: bộ lọc client/dataset/cold-warm/scenario, chọn hiển thị GraphQL naive/batched/cả hai. Biểu đồ, KPI, call graph và waterfall dùng bộ đo thật đã lưu; raw/HAR/log nằm ở cuối trang. [RESULTS.md](RESULTS.md) liên kết evidence cuối.

## Báo cáo nộp bài

[REPORT.md](REPORT.md) là nội dung báo cáo; [REPORT.html](REPORT.html) là bản trình bày tự chứa CSS/SVG, mở offline hoặc in A4 bằng browser. Khi demo chạy, bấm **Báo cáo nộp bài** hoặc mở **http://localhost:3000/report**. Báo cáo ghi lý do lựa chọn, phương án thay thế, trade-off, policy lỗi, cách đo và kết quả320 mẫu cuối.

Chỉnh REPORT.md rồi chạy `npm run report:render` để cập nhật HTML; renderer dùng bộ evidence cuối để dựng hai biểu đồ đo thật. Khi nộp, đính kèm các thư mục evidence được dẫn trong báo cáo.

## API và dữ liệu

| Process | Port | API |
|---|---:|---|
| App BFF + GraphQL + UI | 3000 | `/bff/web/dashboard`, `/bff/mobile/orders`, `POST /graphql` |
| User | 3001 | `GET /users/:id` |
| Order | 3002 | `GET /orders?user_id=U1` |
| Product | 3003 | `GET /products/:id`, `POST /products/batch` body `{ids:[...]}` |

BFF/GraphQL chỉ gọi HTTP, không kết nối DB. Bảng STRICT, SQL tham số hóa:

- users(id,name)
- orders(id,user_id,product_id,quantity,total_cents,status,created_at)
- products(id,name,price_cents,thumbnail_url)

Mỗi đơn một product; small5 đơn theo P1/P2/P1/P3/P2, large100 đơn lặp P1–P5. Thumbnail local. Tổng tiền đơn được lưu, không tính lại theo giá hiện tại. `_cents` dùng đơn vị tiền tệ giả định100cents/unit, không phải VND. Không có `unit_price_cents` hoặc `description`.

BFF web trả `{user,orders,errors}` với Order đầy đủ và Product. BFF mobile chỉ có id/status/product_name/thumbnail_url trong mỗi đơn. Baseline/GraphQL normalize về cùng view model và cùng hàm render, không làm mất đơn có product trùng.

### GraphQL

Query mẫu và adapter ở `public/graphql-client.js`. Mode là biến `product_mode:NAIVE|BATCHED`, không phải cấu hình process. Ví dụ:

```graphql
query WebDashboard($user_id: ID!, $product_mode: ProductMode!) {
  user(id: $user_id) { id name }
  orders(user_id: $user_id, product_mode: $product_mode) {
    id user_id product_id quantity total_cents status created_at
    product { id name price_cents thumbnail_url }
  }
}
```

User/Order là hai root độc lập để User lỗi vẫn giữ được đơn. Product nullable; GraphQL errors có `path` và `extensions` scope/resource_id/code. Mobile query chỉ lấy trường đơn cần hiển thị và `user{id}` để kiểm tra User/hiển thị lỗi User; không lấy tên hay đầy đủ trường đơn/product.

- Naive: resolver Product mỗi đơn, gọi song song; N call và N SQL Product dù browser chỉ có một operation.
- Batched: DataLoader mới mỗi operation, cache/dedup trong request; batch dùng một SQL IN, map kết quả về đúng key. Không cache xuyên request.
- GraphQL envelope khác BFF DTO; payload đo là body thật browser nhận trước normalize, kể cả errors/path.

## Policy lỗi

Giữ dữ liệu thành công; phần không lấy được null và hiển thị lỗi ngay tại vùng đó. Không giả tên/giá/ảnh, không giữ kết quả cũ.

- User lỗi: vẫn lấy đơn bằng userID đầu vào.
- Order lỗi: orders=null, khác orders=[] khi chưa có đơn.
- Product lỗi/thiếu: giữ mã đơn/trạng thái/số lượng/tổng tiền; product hoặc tên/thumbnail=null.
- Timeout mỗi call upstream1000ms, không retry. Browser chờ GraphQL operation tối đa10giây để nhận partial response.
- BFF partial trả HTTP200 với errors; GraphQL trả HTTP200 với data/errors. Query/body GraphQL sai trả400. BFF input sai400, lỗi server ngoài dự kiến500.
- Error codes: RESOURCE_NOT_FOUND / UPSTREAM_ERROR / UPSTREAM_TIMEOUT. Adapter dedup lỗi theo productID, thêm order_ids cho các card liên quan; raw GraphQL errors.path vẫn được giữ trong response/HAR.

## Kiểm thử và bộ đo đầy đủ

Cài Chromium một lần cho test/đo tự động:

```bash
npx playwright install chromium
npm run typecheck
npm test
```

Dừng demo trước khi chạy các bộ đo sau (runner tự quản lý process/seed):

```bash
npm run measure
npm run evidence:failure
```

- Healthy: 4 biến thể × 2 client × 2 dataset × cold/warm × 5 = **160 mẫu**.
- Failure: 4 scenario (slow/timeout/error/missing) × 4 biến thể × 2 client × 5 small/warm = **160 mẫu**.
- Cold restart cả bốn process mỗi mẫu; warm có một lượt không tính rồi5 mẫu. Context mới, API no-store, không nén/throttling, chạy tuần tự.
- Mốc bắt đầu ngay trước API đầu; kết thúc sau DOM, thumbnail decode và hai animation frames. Đổi cấu hình không nằm trong duration.
- `browser_api_requests`: API dữ liệu, không tính settings/metrics/HTML/JS/CSS/ảnh. BFF/GraphQL một request; baseline N+2.
- `service_calls`: outgoing call của app; đếm thêm request từng data service nhận và SQL tại wrapper get/all. Loại setup/health/PRAGMA.
- `api_bytes`: tổng body JSON UTF-8 browser nhận, không headers; timeout chưa nhận body=0. Upstream/static báo riêng.
- run_id truyền bằng query từ browser, header xuống REST, liên kết JSONL/HAR/SQL.
- Timeout có thể vẫn chạy SQL sau client abort. Collector chờ thêm1700ms ngoài duration để thu việc này. Timing abort cũ thiếu start được dashboard khôi phục từ HAR; collector mới ghi mốc request-event dự phòng.

Artifact timestamp trong `evidence/healthy-*`, `evidence/failure-*`: raw.csv/json, summary.json, logs.jsonl, HAR và model từng lượt, equality.json, report.html. Dashboard chọn bản đầy đủ mới nhất, bỏ quick/incomplete/superseded. Artifacts local được gitignore, cần đính kèm khi nộp. `npm run measure -- --quick` chỉ smoke test, không thay số đo full.

UI settings/metrics là công cụ demo thông qua IPC của runner dev; trong lúc bộ đo tự động quản lý cluster, thay đổi cấu hình UI bị từ chối để không làm lệch dữ liệu đo.

## Những điểm cần giải thích

Với N đơn: baseline browserN+2, ProductN SQL; BFF browser1, Product1 SQL; GraphQL naive browser1, ProductN SQL; GraphQL batched browser1, Product1 SQL. Phân biệt composition với tối ưu batch/dedup. Naive gọi Product song song, nên thời gian không nhất thiết tăng tuyến tính dù số call tăng.

Payload web có thể lớn hơn do response ghép/GraphQL envelope; mobile giảm overfetch nhờ DTO/query. Số liệu thực tế và khoảng giá trị quyết định kết luận, không ép phương pháp nào luôn nhanh hơn.

Giới hạn: localhost, mobile mô phỏng browser, process restart không xóa OS disk cache, thứ tự đo cố định, dữ liệu giả nhỏ, không auth/pagination/cache liên request. Một lượt so sánh UI không phải phép đo production.

Trình bày: Problem → chọn100đơn và so sánh3 phương pháp → chỉ rõ N+1 naive và bật batched ngay trên UI → chuyểnmobile → làm Product lỗi → mở Dashboard/Evidence → Trade-off.
