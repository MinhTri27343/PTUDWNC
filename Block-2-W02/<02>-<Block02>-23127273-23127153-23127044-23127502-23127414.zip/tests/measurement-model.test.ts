import test from 'node:test';
import assert from 'node:assert/strict';
import { statistics, selectedRows, compare, change } from '../public/measurement-model.js';
test('dashboard median/range uses real samples, including even sample count and unavailable values',()=>{
 assert.deepEqual(statistics([10,30,20,40,50]),{median:30,min:10,max:50,count:5});
 assert.deepEqual(statistics([40,10,20,30]),{median:25,min:10,max:40,count:4});
 assert.equal(statistics([NaN]),null);
 assert.equal(change(100,20),80);assert.equal(change(20,30),-50);assert.equal(change(0,1),null);
});
test('dashboard isolates client/dataset/mode/state and does not mix failed with complete samples',()=>{
 const selection={scenario:'healthy',client:'web',dataset:'large',mode:'warm',state:'complete'};
 const rows=[{...selection,variant:'baseline',duration_ms:100},{...selection,variant:'bff',duration_ms:30},
  {...selection,variant:'bff',mode:'cold',duration_ms:80},{...selection,variant:'bff',state:'partial',duration_ms:10},
  {...selection,variant:'bff',client:'mobile',duration_ms:20}];
 const selected=selectedRows(rows,selection);assert.equal(selected.length,2);
 assert.deepEqual(compare(selected,'duration_ms').map(s=>s.median),[100,30]);
});
