import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { reportsRouter } from '../src/reports.ts';

test('localhost reports: latest complete, filtering, artifact links, empty state', async()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'bff-reports-'));
  const app=express();app.use(reportsRouter(directory));
  const server=app.listen(0,'localhost');
  await new Promise<void>(resolve=>server.once('listening',resolve));
  const address=server.address();assert.ok(address && typeof address==='object');
  const url=`http://localhost:${address.port}`;
  const add=(name:string,environment:Record<string,any>={},superseded=false)=>{
    const folder=path.join(directory,name);fs.mkdirSync(folder);
    fs.writeFileSync(path.join(folder,'raw.json'),JSON.stringify({environment:{created_at:'2026-10-08T02:00:00Z',...environment},rows:[{}]}));
    fs.writeFileSync(path.join(folder,'report.html'),`<h1>${name}</h1><a href="sample.har">HAR</a>`);
    fs.writeFileSync(path.join(folder,'sample.har'),'fixture HAR');
    if(superseded) fs.writeFileSync(path.join(folder,'SUPERSEDED.txt'),'old seed');
  };
  try {
    const submitted=await fetch(`${url}/report`);assert.equal(submitted.status,200);assert.match(await submitted.text(),/Báo cáo Block 2/);
    assert.equal((await fetch(`${url}/REPORT.md`)).status,200);
    let page=await (await fetch(`${url}/measurements`)).text();assert.match(page,/Chưa có báo cáo đầy đủ/);
    assert.equal((await fetch(`${url}/measurements/latest/healthy`,{redirect:'manual'})).headers.get('location'),'/measurements');
    add('healthy-2026-10-08T01-00-00-000Z');
    add('healthy-2026-10-08T02-00-00-000Z');
    add('healthy-2026-10-08T03-00-00-000Z',{quick:true});
    add('healthy-2026-10-08T04-00-00-000Z',{incomplete:true});
    add('healthy-2026-10-08T05-00-00-000Z',{},true);
    add('failure-2026-10-08T02-00-00-000Z');
    const healthy=await fetch(`${url}/measurements/latest/healthy`,{redirect:'manual'});
    assert.equal(healthy.headers.get('location'),'/measurements?kind=healthy');
    assert.equal((await fetch(`${url}/measurements/latest/failure`,{redirect:'manual'})).headers.get('location'),'/measurements?kind=failure');
    assert.equal((await fetch(`${url}/measurements/latest/unknown`)).status,404);
    page=await (await fetch(`${url}/measurements`)).text();
    assert.match(page,/chart-browser/);assert.match(page,/không phải số liệu live/);
    const data=await (await fetch(`${url}/measurements/data`)).json();
    assert.equal(data.sources.healthy.name,'healthy-2026-10-08T02-00-00-000Z');
    assert.equal(data.sources.failure.name,'failure-2026-10-08T02-00-00-000Z');
    assert.equal(data.reports.length,3);
    assert.equal(data.sources.healthy.rows[0].outcome,null);
    for(const hour of ['03','04','05']) assert.ok(!page.includes(`T${hour}-00-00`));
    const report=await fetch(`${url}/evidence/${data.sources.healthy.name}/report.html`);assert.equal(report.status,200);assert.match(await report.text(),/sample.har/);
    assert.equal(await (await fetch(`${url}/evidence/healthy-2026-10-08T02-00-00-000Z/sample.har`)).text(),'fixture HAR');
  } finally {
    server.closeAllConnections();await new Promise<void>(resolve=>server.close(()=>resolve()));
    fs.rmSync(directory,{recursive:true,force:true});
  }
});
