import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { reportRequests } from '../src/report-timing.ts';
test('timeout waterfall recovers missing start from saved HAR, matching repeated URLs in order',()=>{
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'bff-timing-'));
 try {
  const origin=Date.parse('2026-10-08T02:00:00Z');
  const row={run_id:'timeout-1',requests:[{url:'http://localhost/users/U1',method:'GET',absoluteStart:origin+1,start:1,end:3},
   {url:'http://localhost/products/P1',method:'GET',absoluteStart:0,start:-origin,end:1004},
   {url:'http://localhost/products/P1',method:'GET',absoluteStart:0,start:-origin,end:2005}]};
  fs.writeFileSync(path.join(directory,'timeout-1.har'),JSON.stringify({log:{entries:[
   {request:{method:'GET',url:'http://localhost/products/P1'},startedDateTime:new Date(origin+4).toISOString(),time:1000},
   {request:{method:'GET',url:'http://localhost/products/P1'},startedDateTime:new Date(origin+1005).toISOString(),time:1000} ]}}));
  const result=reportRequests(row,directory);
  assert.equal(result[0],row.requests[0]);assert.deepEqual(result.slice(1).map((r:any)=>[r.start,r.end]),[[4,1004],[1005,2005]]);
  assert.equal(row.requests[1].absoluteStart,0,'source artifacts remain unchanged');
  assert.equal(result[1].timing_source,'saved-HAR');
  fs.rmSync(path.join(directory,'timeout-1.har'));assert.equal(reportRequests(row,directory)[1].start,null);
 }finally{fs.rmSync(directory,{recursive:true,force:true});}
});
