import test from 'node:test';
import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import path from 'node:path';
import fs from 'node:fs';
import { randomUUID } from 'node:crypto';
import { seed, root } from '../scripts/seed.ts';
import { Cluster, sleep } from '../scripts/runner.ts';
import { baseline } from '../public/baseline.js';
import { summarize } from '../scripts/report.ts';
async function model(client='web',uid='U1',run=randomUUID()) {
  const endpoint=client==='web'?'web/dashboard':'mobile/orders';
  const response=await fetch(`http://localhost:3000/bff/${endpoint}?user_id=${uid}&run_id=${run}`);
  assert.equal(response.status,200); assert.ok(response.headers.get('x-request-id'));
  return response.json();
}
test('integration acceptance — real HTTP, separate SQLite processes, browser', async t=>{
  const cluster=new Cluster();
  const restart=async(dataset='small',environment:Record<string,string>={})=>{await cluster.stop();seed(dataset);await cluster.start(environment);};
  try {
    for (const dataset of ['small','large']) await t.test(`${dataset}: baseline/BFF equality, mobile projection, measured calls and SQL`,async()=>{
      await restart(dataset);
      for (const client of ['web','mobile']) {
        const run=randomUUID();
        const bff=await model(client,'U1',run);
        const direct=await baseline('U1',client,randomUUID());
        assert.deepEqual(bff,direct);
        assert.equal(bff.orders.length,dataset==='small'?5:100);
        assert.deepEqual(bff.errors,[]);
        if (client === 'web') assert.ok(new Set(bff.orders.map((order:any)=>order.product_id)).size < bff.orders.length, 'seed must repeat products in each dataset');
        if(client==='mobile') for(const order of bff.orders) assert.deepEqual(Object.keys(order),['id','status','product_name','thumbnail_url']);
        else { assert.equal(bff.orders[0].quantity,1);assert.equal(bff.orders[0].total_cents,120000);assert.ok(!('unit_price_cents' in bff.orders[0]));assert.ok(!('description' in bff.orders[0].product)); }
        await sleep(30);
        const events=cluster.events.filter(e=>e.run_id===run);
        assert.equal(events.filter(e=>e.event==='service_call').length,3);
        assert.equal(events.filter(e=>e.event==='request_start'&&e.service==='product').length,1);
        assert.equal(events.filter(e=>e.event==='db_query'&&e.service==='product').length,1);
        assert.equal(events.filter(e=>e.event==='db_query').length,3);
      }
    });
    await t.test('empty orders, input errors, batch validation, unknown user',async()=>{
      await restart();
      const run=randomUUID();const empty=await model('web','U2',run);
      assert.deepEqual(empty.orders,[]);assert.deepEqual(empty.errors,[]);await sleep(30);
      assert.equal(cluster.events.filter(e=>e.run_id===run&&e.target==='product').length,0);
      assert.equal((await fetch('http://localhost:3000/bff/web/dashboard')).status,400);
      assert.equal((await fetch('http://localhost:3000/bff/mobile/orders?user_id=bad%20id')).status,400);
      for(const body of [{ids:[]},{ids:['P1',2]},{ids:['P1'],extra:true}]) assert.equal((await fetch('http://localhost:3003/products/batch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})).status,400);
      const missing=await model('web','UNKNOWN');assert.equal(missing.user,null);assert.deepEqual(missing.orders,[]);assert.equal(missing.errors[0].code,'RESOURCE_NOT_FOUND');
      const badJson=await fetch('http://localhost:3003/products/batch',{method:'POST',headers:{'Content-Type':'application/json'},body:'{'});assert.equal(badJson.status,400);
    });
    for(const [scenario,environment,code] of [
      ['missing',{PRODUCT_MISSING_ID:'P1'},'RESOURCE_NOT_FOUND'],
      ['error',{PRODUCT_FAIL:'true'},'UPSTREAM_ERROR'],
      ['timeout',{PRODUCT_DELAY_MS:'1500'},'UPSTREAM_TIMEOUT']
    ] as [string,Record<string,string>,string][]) await t.test(`partial Product ${scenario}: both client models match`,async()=>{
      await restart('small',environment);
      for(const client of ['web','mobile']) {
        const bff=await model(client);const direct=await baseline('U1',client,randomUUID());assert.deepEqual(bff,direct);
        assert.equal(bff.orders.length,5);assert.ok(bff.errors.every((e:any)=>e.code===code));
        assert.equal(bff.errors.length,scenario==='missing'?1:3);
        assert.deepEqual(bff.errors[0].order_ids,['O001','O003']);
        if(client==='web'){assert.equal(bff.orders[0].product,null);assert.equal(bff.orders[0].total_cents,120000);assert.ok(bff.user);}
        else{assert.equal(bff.orders[0].product_name,null);assert.equal(bff.orders[0].thumbnail_url,null);}
      }
    });
    await t.test('User down keeps orders; Order down keeps user; all down gives HTTP200 errors',async()=>{
      await restart();await cluster.stopService('user');
      const userDown=await model();assert.equal(userDown.user,null);assert.equal(userDown.orders.length,5);assert.equal(userDown.errors[0].scope,'user');
      assert.deepEqual(userDown,await baseline('U1','web',randomUUID()));
      await restart();await cluster.stopService('order');
      const run=randomUUID();const orderDown=await model('web','U1',run);assert.ok(orderDown.user);assert.equal(orderDown.orders,null);assert.equal(orderDown.errors[0].scope,'orders');
      assert.deepEqual(orderDown,await baseline('U1','web',randomUUID()));
      await sleep(30);assert.equal(cluster.events.filter(e=>e.run_id===run&&e.target==='product').length,0);
      await cluster.stopService('user');await cluster.stopService('product');
      const allDown=await model();assert.equal(allDown.user,null);assert.equal(allDown.orders,null);assert.equal(allDown.errors.length,2);
    });
    await t.test('browser UI: correct regions, shared rendering, no stale data, image decode',async()=>{
      await restart();
      const browser=await chromium.launch();
      const directory=path.join(root,'evidence','ui');fs.mkdirSync(directory,{recursive:true});
      try {
        const page=await browser.newPage({viewport:{width:1100,height:900}});
        const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
        await page.goto('http://localhost:3000/?autorun=1&variant=bff&client=web');
        await page.waitForSelector('#screen[data-state="ready"]');
        assert.equal(await page.locator('.order').count(),5);assert.equal(await page.locator('.error').count(),0);
        assert.equal(await page.locator('img').evaluateAll(images=>images.every(image=>(image as HTMLImageElement).complete)),true);
        await page.screenshot({path:path.join(directory,'web.png'),fullPage:true});
        await cluster.stop();await cluster.start({PRODUCT_MISSING_ID:'P1'});
        await page.locator('#controls button[type=submit]').click();await page.waitForSelector('#screen[data-state="ready"]');
        assert.equal(await page.locator('[data-order-id="O001"] h3').count(),0);
        assert.match(await page.locator('[data-order-id="O001"] .error').innerText(),/RESOURCE_NOT_FOUND/);
        assert.equal(await page.locator('.order h3').count(),3);
        for(const variant of ['baseline','bff']) {
          await page.goto(`http://localhost:3000/?autorun=1&variant=${variant}&client=mobile`);
          await page.waitForSelector('#screen[data-state="ready"]');
          assert.equal(await page.locator('.order').count(),5);assert.equal(await page.locator('.meta').count(),0);assert.equal(await page.locator('.error').count(),2);
        }
        await page.screenshot({path:path.join(directory,'mobile-partial.png'),fullPage:true});
        await cluster.stopService('order');
        await page.goto('http://localhost:3000/?autorun=1&variant=bff&client=web');await page.waitForSelector('#screen[data-state="ready"]');
        assert.equal(await page.locator('.user strong').count(),1);assert.equal(await page.locator('.order').count(),0);assert.equal(await page.locator('[data-error-scope="orders"]').count(),1);
        assert.deepEqual(errors,[]);
      } finally {await browser.close();}
    });
  } finally {await cluster.stop();}
});
test('report computes median/range and separates partial samples',()=>{
  const rows=[1,3,2,5,4].map(value=>({scenario:'healthy',variant:'bff',client:'web',dataset:'small',mode:'warm',state:'complete',duration_ms:value,browser_api_requests:1,service_calls:3,db_queries:3,api_bytes:10,upstream_bytes:20,static_bytes:30}));
  const summary=summarize([...rows,{...rows[0],state:'partial',duration_ms:100}]);
  assert.equal(summary.length,2);assert.deepEqual(summary[0].metrics.duration_ms,{median:3,min:1,max:5});assert.equal(summary[0].count,5);
});
