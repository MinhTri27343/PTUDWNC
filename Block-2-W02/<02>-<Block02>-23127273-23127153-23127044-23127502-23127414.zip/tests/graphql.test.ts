import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {chromium} from 'playwright';
import {Cluster,sleep} from '../scripts/runner.ts';
import {seed} from '../scripts/seed.ts';
import {baseline} from '../public/baseline.js';
import {queries,graphQLModel} from '../public/graphql-client.js';
const endpoint='http://localhost:3000';
async function gql(client='web',mode='batched',run=randomUUID(),user='U1'){
 const response=await fetch(`${endpoint}/graphql?run_id=${run}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:queries[client as keyof typeof queries],variables:{user_id:user,product_mode:mode.toUpperCase()}})});
 assert.equal(response.status,200);const raw=await response.json();return {raw,model:graphQLModel(raw,client)};
}
test('integrated GraphQL shares REST/SQLite, naive N+1 versus request-scoped batching',async t=>{
 const cluster=new Cluster();
 const start=async(dataset='small',env:Record<string,string>={})=>{await cluster.stop();seed(dataset);await cluster.start(env);};
 try{
  for(const dataset of ['small','large'])await t.test(`${dataset}: equality, mobile, counters and request-scoped loader`,async()=>{
   await start(dataset);
   for(const mode of ['naive','batched'])for(const client of ['web','mobile']){
    const run=randomUUID();const {model,raw}=await gql(client,mode,run);assert.equal(raw.errors,undefined);
    assert.deepEqual(model,await baseline('U1',client,randomUUID()));await sleep(40);
    const events=cluster.events.filter(event=>event.run_id===run);const n=dataset==='small'?5:100;
    assert.equal(events.filter(e=>e.event==='service_call').length,mode==='naive'?n+2:3);
    assert.equal(events.filter(e=>e.event==='db_query'&&e.service==='product').length,mode==='naive'?n:1);
    if(client==='mobile')assert.deepEqual(Object.keys(model.orders[0]),['id','status','product_name','thumbnail_url']);
   }
   for(let iteration=0;iteration<2;iteration++){
    const run=randomUUID();await gql('web','batched',run);await sleep(40);
    assert.equal(cluster.events.filter(e=>e.run_id===run&&e.event==='db_query'&&e.service==='product').length,1);
   }
   assert.deepEqual((await gql('web','batched',randomUUID(),'U2')).model.orders,[]);
  });
  for(const [scenario,env]of Object.entries({missing:{PRODUCT_MISSING_ID:'P1'},error:{PRODUCT_FAIL:'true'},timeout:{PRODUCT_DELAY_MS:'1500'}} as Record<string,Record<string,string>>))await t.test(`partial ${scenario}: same view model/errors, GraphQL paths`,async()=>{
   await start('small',env);
   for(const client of ['web','mobile']){
    const expected=await baseline('U1',client,randomUUID());
    for(const mode of ['naive','batched']){
     const {model,raw}=await gql(client,mode);assert.deepEqual(model,expected);assert.equal(model.orders.length,5);
     assert.ok(raw.errors.every((error:any)=>error.path[0]==='orders'&&error.path.at(-1)==='product'));
     assert.deepEqual(model.errors[0].order_ids,['O001','O003']);
    }
   }
  });
  await t.test('User and Order failures stay independent; invalid queries rejected',async()=>{
   await start();await cluster.stopService('user');const userDown=await gql();assert.equal(userDown.model.user,null);assert.equal(userDown.model.orders.length,5);
   await start();await cluster.stopService('order');const orderDown=await gql();assert.ok(orderDown.model.user);assert.equal(orderDown.model.orders,null);
   for(const body of [{query:'{'},{query:'{ unknownField }'},{query:queries.web,variables:{user_id:'U1',product_mode:'OTHER'}},{query:1}]){
    const response=await fetch(`${endpoint}/graphql`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});assert.equal(response.status,400);
   }
  });
  await t.test('UI changes dataset, Product faults and naive/batched; live comparison needs no commands',async()=>{
   await start();cluster.enableDemoControls();
   const browser=await chromium.launch();
   try{
    const page=await browser.newPage();const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
    await page.goto(endpoint);await page.waitForTimeout(100);
    await page.locator('#variant').selectOption('graphql');assert.equal(await page.locator('#graphql-mode-label').isVisible(),true);
    await page.locator('#demo-dataset').selectOption('large');
    await page.locator('#graphql-mode').selectOption('naive');await page.locator('#controls button[type=submit]').click();await page.waitForSelector('#screen[data-state=ready]');
    assert.equal(await page.locator('.order').count(),100);const naive:any=await page.evaluate(()=> (window as any).demoResult);
    await sleep(60);assert.equal(cluster.events.filter(e=>e.run_id===naive.run_id&&e.event==='db_query'&&e.service==='product').length,100);
    await page.locator('#graphql-mode').selectOption('batched');await page.locator('#controls button[type=submit]').click();await page.waitForSelector('#screen[data-state=ready]');
    const batched:any=await page.evaluate(()=> (window as any).demoResult);await sleep(60);assert.equal(cluster.events.filter(e=>e.run_id===batched.run_id&&e.event==='db_query'&&e.service==='product').length,1);
    await page.locator('#demo-dataset').selectOption('small');await page.locator('#demo-scenario').selectOption('missing');await page.locator('#controls button[type=submit]').click();await page.waitForSelector('#screen[data-state=ready]');
    assert.equal(await page.locator('.order').count(),5);assert.equal(await page.locator('.error').count(),2);
    await page.locator('#demo-scenario').selectOption('healthy');await page.locator('#compare-live').click();await page.waitForFunction(()=> (window as any).liveComparison?.length===4,{},{timeout:20000});
    const comparison:any[]=await page.evaluate(()=> (window as any).liveComparison);
    assert.deepEqual(comparison.map(row=>row.browser_api_requests),[7,1,1,1]);assert.deepEqual(comparison.map(row=>row.db_queries),[7,3,7,3]);assert.deepEqual(comparison.map(row=>row.product_requests),[5,1,5,1]);
    assert.equal(await page.locator('#live-comparison tr').count(),5);assert.deepEqual(errors,[]);
   }finally{await browser.close();}
  });
 }finally{await cluster.stop();}
});
